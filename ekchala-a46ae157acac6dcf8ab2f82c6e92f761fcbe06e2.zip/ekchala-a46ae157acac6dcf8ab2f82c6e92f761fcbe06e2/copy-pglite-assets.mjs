import { copyFileSync, existsSync } from "node:fs";

const dest = ".vercel/output/functions/__server.func/_libs";
if (!existsSync(dest)) process.exit(0);

for (const file of ["pglite.data", "pglite.wasm", "initdb.wasm"]) {
  copyFileSync(`node_modules/@electric-sql/pglite/dist/${file}`, `${dest}/${file}`);
}
