import type { ButtonHTMLAttributes, ReactNode } from "react";

export function Btn({
  kind = "solid",
  className = "",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { kind?: "solid" | "ink" | "ghost" }) {
  const look =
    kind === "solid"
      ? "bg-primary text-surface"
      : kind === "ink"
        ? "bg-ink text-surface"
        : "border border-line bg-surface text-ink";
  return (
    <button
      {...props}
      className={`inline-flex min-h-11 items-center justify-center rounded-md px-4 text-sm font-medium disabled:opacity-50 ${look} ${className}`}
    />
  );
}

export function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="block space-y-1 text-sm">
      <span className="text-muted">{label}</span>
      {children}
    </label>
  );
}

export const control =
  "min-h-11 w-full rounded-md border border-line bg-surface px-3 text-ink outline-none focus:border-ink";

export function Tabs({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (id: string) => void;
  options: { id: string; label: string }[];
}) {
  return (
    <div className="no-print -mx-1 flex gap-2 overflow-x-auto px-1 pb-3">
      {options.map((option) => (
        <button
          key={option.id}
          type="button"
          onClick={() => onChange(option.id)}
          className={`min-h-11 shrink-0 rounded-full px-4 text-sm ${
            value === option.id ? "bg-ink text-surface" : "border border-line bg-surface text-ink"
          }`}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <p className="rounded-md border border-dashed border-line px-4 py-8 text-center text-muted">{children}</p>;
}

export function PageTitle({ kicker, title, lede }: { kicker: string; title: string; lede?: string }) {
  return (
    <header className="mb-6 max-w-3xl">
      <p className="text-sm text-primary">{kicker}</p>
      <h1 className="mt-1 text-4xl leading-tight sm:text-5xl">{title}</h1>
      {lede ? <p className="mt-3 text-lg text-muted">{lede}</p> : null}
    </header>
  );
}

export function Speak({ text }: { text: string }) {
  return (
    <Btn
      kind="ghost"
      type="button"
      onClick={() => {
        if (typeof speechSynthesis === "undefined") return;
        const utter = new SpeechSynthesisUtterance(text);
        utter.lang = "bn-BD";
        speechSynthesis.cancel();
        speechSynthesis.speak(utter);
      }}
    >
      শোনাও
    </Btn>
  );
}

export function taka(n: number) {
  return `৳${new Intl.NumberFormat("bn-BD").format(Math.round(n))}`;
}
