import type { ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Toaster } from "sonner";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

const LINKS = [
  { to: "/", label: "ঘর" },
  { to: "/sites", label: "সাইট" },
  { to: "/work", label: "কাজ" },
  { to: "/money", label: "হিসাব" },
  { to: "/make", label: "বানানো" },
  { to: "/day", label: "দিন" },
  { to: "/desk", label: "ডেস্ক" },
  { to: "/board", label: "বোর্ড" },
  { to: "/share", label: "শেয়ার" },
  { to: "/me", label: "আমি" },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  if (path === "/login") return <>{children}</>;
  return (
    <div className="min-h-screen">
      <header className="no-print sticky top-0 z-20 border-b border-line bg-bg/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <Link to="/" className="shrink-0 font-display text-2xl leading-none">
            একচালা
          </Link>
          <nav className="flex min-w-0 flex-1 gap-1 overflow-x-auto">
            {LINKS.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                activeOptions={{ exact: link.to === "/" }}
                className="inline-flex min-h-11 shrink-0 items-center rounded-full px-3 text-sm text-muted"
                activeProps={{ className: "inline-flex min-h-11 shrink-0 items-center rounded-full bg-ink px-3 text-sm text-surface" }}
              >
                {link.label}
              </Link>
            ))}
          </nav>
          <AuthSlot />
        </div>
      </header>
      <div className="mx-auto max-w-6xl px-4 py-6">{children}</div>
      <Toaster position="bottom-center" />
    </div>
  );
}

function AuthSlot() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) return <div className="h-8 w-16 animate-pulse rounded-full bg-line" />;
  if (!user) {
    return (
      <Link to="/login" className="inline-flex min-h-11 shrink-0 items-center text-sm text-primary">
        ঢুকুন
      </Link>
    );
  }
  return (
    <div className="hidden shrink-0 sm:block">
      <UserButton />
    </div>
  );
}
