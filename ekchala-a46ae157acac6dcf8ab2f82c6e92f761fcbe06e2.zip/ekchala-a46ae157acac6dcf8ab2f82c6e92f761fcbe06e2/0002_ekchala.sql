create table if not exists items (
  id         serial primary key,
  user_id    text not null,
  kind       text not null,
  payload    text not null,
  created_at timestamptz not null default now()
);
create index if not exists items_user_kind_idx on items (user_id, kind);

create table if not exists profiles (
  user_id      text primary key,
  display_name text not null default '',
  city         text not null default '',
  about        text not null default ''
);

create table if not exists scores (
  id           serial primary key,
  user_id      text not null,
  display_name text not null,
  game         text not null,
  points       integer not null,
  created_at   timestamptz not null default now()
);
create index if not exists scores_points_idx on scores (points desc);

create table if not exists shares (
  code       text primary key,
  user_id    text not null,
  title      text not null,
  body       text not null,
  created_at timestamptz not null default now()
);
create index if not exists shares_user_idx on shares (user_id);
