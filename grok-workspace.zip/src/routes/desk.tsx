import { useCallback, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { redirectToLoginIfRequired, useRefetchWhenConnectorReady } from "@/lib/app-data";
import { fetchDesk } from "@/lib/ekchala/server";
import { Btn, control, PageTitle } from "@/components/ui";

export const Route = createFileRoute("/desk")({ component: Desk });

type Block = {
  ok: boolean;
  message: string;
  loginRequired: boolean;
  loginUrl?: string;
  pending: boolean;
  rows: { title: string; meta: string }[];
};

function Desk() {
  const [query, setQuery] = useState("");
  const [calendar, setCalendar] = useState<Block | null>(null);
  const [drive, setDrive] = useState<Block | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setBusy(true);
    try {
      const result = await fetchDesk({ data: { driveQuery: query } });
      setCalendar(result.calendar);
      setDrive(result.drive);
    } catch {
      const fail: Block = {
        ok: false,
        message: "এখন লোড হয়নি। Grok থেকে খুললে ক্যালেন্ডার ও ড্রাইভ আসে।",
        loginRequired: false,
        pending: false,
        rows: [],
      };
      setCalendar(fail);
      setDrive(fail);
    } finally {
      setBusy(false);
    }
  }, [query]);

  const waiting = Boolean(calendar?.pending || drive?.pending);
  useRefetchWhenConnectorReady(waiting, () => {
    void load();
  });

  return (
    <div>
      <PageTitle
        kicker="ডেস্ক"
        title="আপনার ক্যালেন্ডার ও ড্রাইভ।"
        lede="Gmail আর Notion এই ঘরে জোড়া নেই — যে টুল খোলা আছে সেগুলো ক্যালেন্ডার ও ড্রাইভ। Grok-এ অ্যাকাউন্ট জুড়লে খবর আসে।"
      />
      <div className="mb-4 flex flex-wrap gap-2">
        <input className={`${control} max-w-xs`} placeholder="ড্রাইভে খুঁজুন" value={query} onChange={(e) => setQuery(e.target.value)} />
        <Btn type="button" onClick={() => void load()} disabled={busy}>{busy ? "আসছে…" : "আনুন"}</Btn>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Pane title="সামনের সাত দিন" block={calendar} />
        <Pane title="ড্রাইভ" block={drive} />
      </div>
    </div>
  );
}

function Pane({ title, block }: { title: string; block: Block | null }) {
  return (
    <section className="rounded-md border border-line bg-surface p-4">
      <h2 className="text-2xl">{title}</h2>
      {!block ? <p className="mt-3 text-muted">এখনো আনা হয়নি।</p> : null}
      {block && !block.ok ? <p className="mt-3 text-muted">{block.message}</p> : null}
      {block?.loginRequired ? (
        <button
          type="button"
          className="mt-3 min-h-11 text-primary"
          onClick={() =>
            redirectToLoginIfRequired({
              ok: false,
              data: null,
              loginRequired: true,
              loginUrl: block.loginUrl,
            })
          }
        >
          Grok দিয়ে চালিয়ে যান
        </button>
      ) : null}
      <ul className="mt-3 space-y-2">
        {block?.rows.map((row) => (
          <li key={`${row.title}-${row.meta}`} className="border-b border-line py-2">
            <p>{row.title}</p>
            {row.meta ? <p className="text-sm text-muted">{row.meta}</p> : null}
          </li>
        ))}
      </ul>
      {block?.ok && block.rows.length === 0 ? <p className="mt-3 text-muted">কিছু পাওয়া যায়নি।</p> : null}
    </section>
  );
}
