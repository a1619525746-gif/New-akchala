import { useEffect, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { businesses, articles, course, docs, portfolio, products } from "@/lib/ekchala/content";
import { useItems } from "@/lib/ekchala/use-items";
import { Btn, control, Empty, PageTitle, Speak, Tabs, taka } from "@/components/ui";

export const Route = createFileRoute("/sites")({ component: Sites });

type Mode = "biz" | "folio" | "press" | "shop" | "promo";

function Sites() {
  const [mode, setMode] = useState<Mode>("biz");
  return (
    <div>
      <PageTitle kicker="সাইট স্টুডিও" title="যে পাতা খুললেই সাইট।" lede="একই ঘরে ব্যবসা, কাজের খাতা, লেখা, দোকান, আর নিমন্ত্রণ।" />
      <Tabs
        value={mode}
        onChange={(id) => setMode(id as Mode)}
        options={[
          { id: "biz", label: "ব্যবসা" },
          { id: "folio", label: "পোর্টফোলিও" },
          { id: "press", label: "পত্রিকা" },
          { id: "shop", label: "দোকান" },
          { id: "promo", label: "নিমন্ত্রণ" },
        ]}
      />
      {mode === "biz" ? <Biz /> : null}
      {mode === "folio" ? <Folio /> : null}
      {mode === "press" ? <Press /> : null}
      {mode === "shop" ? <Shop /> : null}
      {mode === "promo" ? <Promo /> : null}
    </div>
  );
}

function Biz() {
  const [id, setId] = useState(businesses[0].id);
  const biz = businesses.find((item) => item.id === id) ?? businesses[0];
  return (
    <div className="space-y-6">
      <Tabs value={id} onChange={setId} options={businesses.map((item) => ({ id: item.id, label: item.kind }))} />
      <article className="overflow-hidden rounded-md border border-line bg-surface">
        <div className="bg-ink px-6 py-10 text-surface">
          <p className="text-sm text-line">{biz.kind} · {biz.place}</p>
          <h2 className="mt-3 text-5xl text-surface">{biz.name}</h2>
          <p className="mt-4 max-w-xl text-lg text-line">{biz.line}</p>
        </div>
        <div className="space-y-8 px-6 py-8">
          <p className="max-w-2xl text-lg">{biz.about}</p>
          <div className="grid gap-px overflow-hidden rounded-md border border-line bg-line sm:grid-cols-3">
            {biz.services.map((service) => (
              <div key={service.name} className="bg-surface p-4">
                <p className="text-sm text-muted">{service.detail}</p>
                <h3 className="mt-2 text-2xl">{service.name}</h3>
                <p className="mt-2 tabular-nums text-primary">{service.price}</p>
              </div>
            ))}
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {biz.reviews.map((review) => (
              <blockquote key={review.name} className="border-l-2 border-primary pl-4">
                <p>{review.text}</p>
                <footer className="mt-2 text-sm text-muted">{review.name}</footer>
              </blockquote>
            ))}
          </div>
          <div className="space-y-2">
            {biz.faqs.map((faq) => (
              <details key={faq.q} className="rounded-md border border-line px-4 py-3">
                <summary className="min-h-11 cursor-pointer">{faq.q}</summary>
                <p className="pb-2 text-muted">{faq.a}</p>
              </details>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-3 border-t border-line pt-4">
            <p className="text-muted">{biz.address}</p>
            <a
              className="inline-flex min-h-11 items-center text-primary"
              href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(biz.map)}`}
              target="_blank"
              rel="noreferrer"
            >
              ম্যাপে দেখুন
            </a>
          </div>
        </div>
      </article>
    </div>
  );
}

function Folio() {
  return (
    <article className="space-y-8">
      <header>
        <p className="text-primary">{portfolio.role}</p>
        <h2 className="text-5xl">{portfolio.name}</h2>
        <p className="mt-3 max-w-2xl text-lg text-muted">{portfolio.about}</p>
      </header>
      <ol className="space-y-6">
        {portfolio.projects.map((project, index) => (
          <li key={project.title} className="grid gap-3 border-t border-line pt-6 sm:grid-cols-[8rem_1fr]">
            <p className="font-display text-4xl tabular-nums text-primary">০{index + 1}</p>
            <div>
              <p className="text-sm text-muted">{project.kind} · {project.year}</p>
              <h3 className="text-3xl">{project.title}</h3>
              <p className="mt-2 max-w-xl">{project.text}</p>
            </div>
          </li>
        ))}
      </ol>
      <p className="text-muted">যোগাযোগ: {portfolio.contact}</p>
    </article>
  );
}

function Press() {
  const [tab, setTab] = useState("write");
  const [open, setOpen] = useState(articles[0].id);
  const piece = articles.find((item) => item.id === open) ?? articles[0];
  return (
    <div>
      <Tabs
        value={tab}
        onChange={setTab}
        options={[
          { id: "write", label: "লেখা" },
          { id: "course", label: "কোর্স" },
          { id: "docs", label: "ডক" },
        ]}
      />
      {tab === "write" ? (
        <div className="grid gap-6 lg:grid-cols-[16rem_1fr]">
          <div className="space-y-2">
            {articles.map((article) => (
              <button
                key={article.id}
                type="button"
                onClick={() => setOpen(article.id)}
                className={`block min-h-11 w-full rounded-md px-3 text-left ${open === article.id ? "bg-ink text-surface" : "bg-surface"}`}
              >
                {article.title}
              </button>
            ))}
          </div>
          <article className="rounded-md border border-line bg-surface p-6">
            <p className="text-sm text-primary">{piece.kicker}</p>
            <h2 className="mt-2 text-4xl">{piece.title}</h2>
            <p className="mt-4 text-lg leading-relaxed">{piece.body}</p>
            <div className="mt-4">
              <Speak text={`${piece.title}. ${piece.body}`} />
            </div>
          </article>
        </div>
      ) : null}
      {tab === "course" ? (
        <ol className="space-y-3">
          {course.map((step) => (
            <li key={step.name} className="rounded-md border border-line bg-surface p-4">
              <h3 className="text-2xl">{step.name}</h3>
              <p className="text-muted">{step.detail}</p>
            </li>
          ))}
        </ol>
      ) : null}
      {tab === "docs" ? (
        <ul className="space-y-3">
          {docs.map((doc) => (
            <li key={doc.name} className="rounded-md border border-line bg-surface p-4">
              <h3 className="text-2xl">{doc.name}</h3>
              <p className="text-muted">{doc.detail}</p>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

type Cart = { id: string; qty: number };

function Shop() {
  const [tag, setTag] = useState("সব");
  const [cart, setCart] = useState<Cart[]>([]);
  const [open, setOpen] = useState<string | null>(null);
  const [note, setNote] = useState("");
  const orders = useItems<{ lines: string; note: string }>("order");
  const tags = ["সব", ...new Set(products.map((item) => item.tag))];
  const shown = products.filter((item) => tag === "সব" || item.tag === tag);
  const product = products.find((item) => item.id === open);
  const total = cart.reduce((sum, line) => {
    const item = products.find((p) => p.id === line.id);
    return sum + (item ? item.price * line.qty : 0);
  }, 0);
  const slip = useMemo(
    () =>
      cart
        .map((line) => {
          const item = products.find((p) => p.id === line.id);
          return item ? `${item.name} × ${line.qty}` : "";
        })
        .filter(Boolean)
        .join(", "),
    [cart],
  );

  function add(id: string) {
    setCart((prev) => {
      const found = prev.find((line) => line.id === id);
      if (found) return prev.map((line) => (line.id === id ? { ...line, qty: line.qty + 1 } : line));
      return [...prev, { id, qty: 1 }];
    });
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_18rem]">
      <div>
        <Tabs value={tag} onChange={setTag} options={tags.map((item) => ({ id: item, label: item }))} />
        <div className="grid gap-3 sm:grid-cols-2">
          {shown.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setOpen(item.id)}
              className="rounded-md border border-line bg-surface p-4 text-left"
            >
              <p className="text-sm text-muted">{item.tag}</p>
              <h3 className="text-2xl">{item.name}</h3>
              <p className="mt-2 tabular-nums">{taka(item.price)}</p>
            </button>
          ))}
        </div>
        {product ? (
          <div className="mt-4 rounded-md border border-ink bg-surface p-5">
            <h3 className="text-3xl">{product.name}</h3>
            <p className="mt-2 text-muted">{product.detail}</p>
            <p className="mt-2 tabular-nums text-primary">{taka(product.price)}</p>
            <Btn className="mt-4" type="button" onClick={() => add(product.id)}>
              ব্যাগে রাখুন
            </Btn>
          </div>
        ) : null}
      </div>
      <aside className="h-fit rounded-md border border-line bg-surface p-4">
        <h3 className="text-2xl">ব্যাগ</h3>
        {cart.length === 0 ? <p className="mt-3 text-muted">এখনো খালি।</p> : null}
        <ul className="mt-3 space-y-2">
          {cart.map((line) => {
            const item = products.find((p) => p.id === line.id);
            if (!item) return null;
            return (
              <li key={line.id} className="flex items-center justify-between gap-2 text-sm">
                <span>{item.name} × {line.qty}</span>
                <button type="button" className="min-h-11 text-primary" onClick={() => setCart((prev) => prev.filter((x) => x.id !== line.id))}>
                  বাদ
                </button>
              </li>
            );
          })}
        </ul>
        <p className="mt-3 tabular-nums">মোট {taka(total)}</p>
        <textarea className={`${control} mt-3 min-h-24`} placeholder="ঠিকানা বা নোট" value={note} onChange={(e) => setNote(e.target.value)} />
        <Btn
          className="mt-3 w-full"
          type="button"
          disabled={!slip}
          onClick={async () => {
            await orders.add({ lines: slip, note });
            const text = `অর্ডার: ${slip}. নোট: ${note}. মোট ${taka(total)}`;
            await navigator.clipboard.writeText(text).catch(() => undefined);
            toast("অর্ডার জমা হয়েছে, লেখা কপি হয়েছে");
            setCart([]);
            setNote("");
          }}
        >
          অর্ডার রাখুন
        </Btn>
      </aside>
    </div>
  );
}

function Promo() {
  const target = new Date("2026-12-12T18:00:00+06:00").getTime();
  const [now, setNow] = useState(() => Date.now());
  const [name, setName] = useState("");
  const waits = useItems<{ name: string }>("wait");
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);
  const left = Math.max(0, target - now);
  const days = Math.floor(left / 86400000);
  const hours = Math.floor((left % 86400000) / 3600000);
  return (
    <article className="rounded-md bg-ink px-6 py-12 text-surface">
      <p className="text-sm text-line">১২ ডিসেম্বর · সন্ধ্যা ছয়টা · পুরান ঢাকা</p>
      <h2 className="mt-3 text-5xl text-surface sm:text-6xl">অন্বেষা ও রুদ্র</h2>
      <p className="mt-4 max-w-xl text-lg text-line">বিয়ের সন্ধ্যা। গান একটা, খাবার বসার পর। নাম রাখলে জায়গা রাখা হবে।</p>
      <p className="mt-8 font-display text-4xl tabular-nums text-surface">
        {days} দিন {hours} ঘণ্টা
      </p>
      <form
        className="mt-8 flex max-w-md flex-col gap-3 sm:flex-row"
        onSubmit={async (event) => {
          event.preventDefault();
          if (!name.trim()) return;
          await waits.add({ name: name.trim() });
          toast("নাম রাখা হয়েছে");
          setName("");
        }}
      >
        <input className={`${control} text-ink`} placeholder="আপনার নাম" value={name} onChange={(e) => setName(e.target.value)} />
        <Btn type="submit">আসব</Btn>
      </form>
      {waits.items.length === 0 ? <Empty>এখনো কেউ নাম রাখেনি।</Empty> : null}
      <ul className="mt-4 space-y-1 text-line">
        {waits.items.map((item) => (
          <li key={item.id}>{item.name}</li>
        ))}
      </ul>
    </article>
  );
}
