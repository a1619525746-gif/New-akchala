import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { recipes } from "@/lib/ekchala/content";
import { useItems } from "@/lib/ekchala/use-items";
import { Btn, control, Empty, PageTitle, Tabs } from "@/components/ui";

export const Route = createFileRoute("/day")({ component: Day });

function Day() {
  const [tab, setTab] = useState("sky");
  return (
    <div>
      <PageTitle kicker="দিন" title="আকাশ, হাঁড়ি, আর সপ্তাহ।" />
      <Tabs
        value={tab}
        onChange={setTab}
        options={[
          { id: "sky", label: "আবহাওয়া" },
          { id: "cook", label: "রেসিপি" },
          { id: "plan", label: "পরিকল্পনা" },
        ]}
      />
      {tab === "sky" ? <Sky /> : null}
      {tab === "cook" ? <Cook /> : null}
      {tab === "plan" ? <Plan /> : null}
    </div>
  );
}

type SkyNow = { temp: number; wind: number; code: number; city: string };

function Sky() {
  const [city, setCity] = useState("Dhaka");
  const [now, setNow] = useState<SkyNow | null>(null);
  const [error, setError] = useState("");
  async function load(name: string) {
    setError("");
    try {
      const geo = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(name)}&count=1&language=en`);
      const found = (await geo.json()) as { results?: { latitude: number; longitude: number; name: string }[] };
      const place = found.results?.[0];
      if (!place) {
        setError("শহর পাওয়া যায়নি।");
        return;
      }
      const wx = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${place.latitude}&longitude=${place.longitude}&current=temperature_2m,weather_code,wind_speed_10m`,
      );
      const data = (await wx.json()) as { current?: { temperature_2m: number; weather_code: number; wind_speed_10m: number } };
      if (!data.current) {
        setError("আকাশের খবর আসেনি।");
        return;
      }
      setNow({
        temp: data.current.temperature_2m,
        wind: data.current.wind_speed_10m,
        code: data.current.weather_code,
        city: place.name,
      });
    } catch {
      setError("নেটওয়ার্ক ধরেনি।");
    }
  }
  return (
    <div className="max-w-md space-y-4">
      <form
        className="flex gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          void load(city);
        }}
      >
        <input className={control} value={city} onChange={(e) => setCity(e.target.value)} placeholder="শহর" />
        <Btn type="submit">দেখুন</Btn>
      </form>
      {!now && !error ? <Btn kind="ink" type="button" onClick={() => void load("Dhaka")}>ঢাকার আকাশ</Btn> : null}
      {error ? <p className="text-primary">{error}</p> : null}
      {now ? (
        <div className="rounded-md bg-ink p-6 text-surface">
          <p className="text-sm text-line">{now.city}</p>
          <p className="mt-2 font-display text-6xl tabular-nums text-surface">{Math.round(now.temp)}°</p>
          <p className="mt-2 text-line">{skyWord(now.code)} · বাতাস {Math.round(now.wind)} কিমি/ঘণ্টা</p>
        </div>
      ) : null}
    </div>
  );
}

function skyWord(code: number) {
  if (code === 0) return "পরিষ্কার";
  if (code < 3) return "মেঘলা রোদ";
  if (code < 50) return "কুয়াশা";
  if (code < 70) return "বৃষ্টি";
  if (code < 80) return "বরফ";
  return "ঝড়";
}

function Cook() {
  const [q, setQ] = useState("");
  const [people, setPeople] = useState(2);
  const [open, setOpen] = useState(recipes[0].name);
  const list = recipes.filter((recipe) => recipe.name.includes(q.trim()));
  const recipe = list.find((item) => item.name === open) ?? list[0];
  const scale = recipe ? people / recipe.base : 1;
  return (
    <div className="grid gap-4 lg:grid-cols-[16rem_1fr]">
      <div>
        <input className={control} placeholder="খুঁজুন" value={q} onChange={(e) => setQ(e.target.value)} />
        <ul className="mt-3 space-y-2">
          {list.map((item) => (
            <li key={item.name}>
              <button type="button" className="min-h-11" onClick={() => setOpen(item.name)}>{item.name}</button>
            </li>
          ))}
        </ul>
      </div>
      {recipe ? (
        <article className="rounded-md border border-line bg-surface p-5">
          <h2 className="text-3xl">{recipe.name}</h2>
          <p className="text-muted">{recipe.time}</p>
          <label className="mt-3 block text-sm text-muted">
            কতজন
            <input className={`${control} mt-1 max-w-32`} type="number" min={1} max={12} value={people} onChange={(e) => setPeople(Number(e.target.value) || 1)} />
          </label>
          <p className="mt-3 text-sm text-muted">মূল রেসিপি {recipe.base} জনের। এখন {scale.toFixed(1)} গুণ।</p>
          <ul className="mt-3 list-disc pl-5">
            {recipe.items.map((item) => <li key={item}>{item}</li>)}
          </ul>
          <ol className="mt-3 list-decimal space-y-1 pl-5">
            {recipe.steps.map((step) => <li key={step}>{step}</li>)}
          </ol>
        </article>
      ) : (
        <Empty>এই নামে রান্না নেই।</Empty>
      )}
    </div>
  );
}

function Plan() {
  const bag = useItems<{ bucket: string; title: string; day: string }>("plan");
  const [bucket, setBucket] = useState("পড়ালেখা");
  const [title, setTitle] = useState("");
  const [day, setDay] = useState("শনি");
  const days = ["শনি", "রবি", "সোম", "মঙ্গল", "বুধ", "বৃহ", "শুক্র"];
  const groups = useMemo(() => ["ভ্রমণ", "খাবার", "পড়ালেখা"], []);
  return (
    <div className="space-y-4">
      <Tabs value={bucket} onChange={setBucket} options={groups.map((id) => ({ id, label: id }))} />
      <form
        className="flex flex-wrap gap-2"
        onSubmit={async (event) => {
          event.preventDefault();
          if (!title.trim()) return;
          await bag.add({ bucket, title: title.trim(), day });
          setTitle("");
        }}
      >
        <select className={`${control} max-w-36`} value={day} onChange={(e) => setDay(e.target.value)}>
          {days.map((d) => <option key={d}>{d}</option>)}
        </select>
        <input className={control} placeholder="কী করবেন" value={title} onChange={(e) => setTitle(e.target.value)} />
        <Btn type="submit">রাখুন</Btn>
      </form>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {days.map((d) => (
          <section key={d} className="rounded-md border border-line bg-surface p-3">
            <h3 className="text-xl">{d}</h3>
            <ul className="mt-2 space-y-1 text-sm">
              {bag.items.filter((item) => item.bucket === bucket && item.day === d).map((item) => (
                <li key={item.id} className="flex justify-between gap-2">
                  <span>{item.title}</span>
                  <button type="button" className="text-primary" onClick={() => bag.remove(item.id)}>×</button>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
    </div>
  );
}
