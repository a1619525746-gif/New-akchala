import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { SignInGate } from "@/lib/auth/gates";
import { listScores } from "@/lib/ekchala/server";
import { Empty, PageTitle } from "@/components/ui";

export const Route = createFileRoute("/board")({ component: BoardPage });

type Score = { display_name: string; game: string; points: number };

function BoardPage() {
  return (
    <div>
      <PageTitle kicker="বোর্ড" title="কার কত।" lede="কুইজের স্কোর আর ফোকাস ঘড়ির পঁচিশ। নাম প্রোফাইল থেকে, না থাকলে অ্যাকাউন্টের নাম।" />
      <SignInGate fallback={<p className="text-muted">বোর্ড দেখতে Grok-এর ভেতর থেকে খুলুন, যাতে নাম থাকে।</p>}>
        <List />
      </SignInGate>
    </div>
  );
}

function List() {
  const [rows, setRows] = useState<Score[] | null>(null);
  useEffect(() => {
    let cancel = false;
    listScores()
      .then((data) => {
        if (!cancel) setRows(data);
      })
      .catch(() => {
        if (!cancel) setRows([]);
      });
    return () => {
      cancel = true;
    };
  }, []);
  if (!rows) return <p className="text-muted">লোড হচ্ছে…</p>;
  if (rows.length === 0) return <Empty>এখনো কেউ স্কোর দেয়নি। কুইজ খেলুন।</Empty>;
  return (
    <ol className="max-w-xl space-y-2">
      {rows.map((row, index) => (
        <li key={`${row.display_name}-${row.game}-${index}`} className="flex items-baseline justify-between gap-3 border-b border-line py-3">
          <span className="tabular-nums text-muted">{index + 1}</span>
          <span className="flex-1">{row.display_name}</span>
          <span className="text-sm text-muted">{row.game}</span>
          <span className="tabular-nums">{row.points}</span>
        </li>
      ))}
    </ol>
  );
}
