import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { SignInGate } from "@/lib/auth/gates";
import { readShare } from "@/lib/ekchala/server";
import { PageTitle, Speak } from "@/components/ui";

export const Route = createFileRoute("/s/$code")({ component: ShareView });

function ShareView() {
  const { code } = Route.useParams();
  return (
    <SignInGate fallback={<p className="text-muted">এই লেখা পড়তে একচালায় ঢুকতে হবে।</p>}>
      <Reader code={code} />
    </SignInGate>
  );
}

function Reader({ code }: { code: string }) {
  const [row, setRow] = useState<{ title: string; body: string } | null | undefined>(undefined);
  useEffect(() => {
    let cancel = false;
    readShare({ data: code })
      .then((data) => {
        if (!cancel) setRow(data);
      })
      .catch(() => {
        if (!cancel) setRow(null);
      });
    return () => {
      cancel = true;
    };
  }, [code]);
  if (row === undefined) return <p className="text-muted">লোড হচ্ছে…</p>;
  if (!row) return <PageTitle kicker="শেয়ার" title="পাওয়া যায়নি।" />;
  return (
    <article className="max-w-2xl">
      <PageTitle kicker="শেয়ার করা লেখা" title={row.title} />
      <p className="whitespace-pre-wrap text-lg leading-relaxed">{row.body}</p>
      <div className="mt-4">
        <Speak text={`${row.title}. ${row.body}`} />
      </div>
    </article>
  );
}
