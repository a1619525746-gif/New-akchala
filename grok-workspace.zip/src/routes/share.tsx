import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { SignInGate } from "@/lib/auth/gates";
import { createShare, deleteShare, listMyShares } from "@/lib/ekchala/server";
import { Btn, control, Empty, Field, PageTitle } from "@/components/ui";

export const Route = createFileRoute("/share")({ component: SharePage });

function SharePage() {
  return (
    <div>
      <PageTitle kicker="শেয়ার" title="একটা লেখা অন্যের হাতে।" lede="লিংক খুলতে ওই মানুষকেও একচালায় ঢুকতে হবে।" />
      <SignInGate fallback={<p className="text-muted">শেয়ার করতে Grok থেকে খোলা অ্যাকাউন্ট লাগে।</p>}>
        <Composer />
      </SignInGate>
    </div>
  );
}

function Composer() {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [rows, setRows] = useState<{ code: string; title: string }[]>([]);
  async function refresh() {
    setRows(await listMyShares());
  }
  useEffect(() => {
    let cancel = false;
    listMyShares()
      .then((data) => {
        if (!cancel) setRows(data);
      })
      .catch(() => undefined);
    return () => {
      cancel = true;
    };
  }, []);
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <form
        className="space-y-3"
        onSubmit={async (event) => {
          event.preventDefault();
          const made = await createShare({ data: { title: title.trim(), body: body.trim() } });
          toast("লিংক তৈরি");
          setTitle("");
          setBody("");
          await refresh();
          if (made?.code) setRows((prev) => prev);
        }}
      >
        <Field label="শিরোনাম"><input className={control} value={title} onChange={(e) => setTitle(e.target.value)} /></Field>
        <Field label="লেখা"><textarea className={`${control} min-h-36`} value={body} onChange={(e) => setBody(e.target.value)} /></Field>
        <Btn type="submit" disabled={!title.trim() || !body.trim()}>লিংক বানান</Btn>
      </form>
      <div>
        {rows.length === 0 ? <Empty>এখনো শেয়ার নেই।</Empty> : null}
        <ul className="space-y-3">
          {rows.map((row) => (
            <li key={row.code} className="flex items-center justify-between gap-3 rounded-md border border-line bg-surface px-3 py-2">
              <Link to="/s/$code" params={{ code: row.code }} className="min-h-11 text-primary">{row.title}</Link>
              <button
                type="button"
                className="min-h-11 text-sm"
                onClick={async () => {
                  await deleteShare({ data: row.code });
                  setRows((prev) => prev.filter((item) => item.code !== row.code));
                }}
              >
                মুছুন
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
