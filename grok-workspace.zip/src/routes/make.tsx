import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { names, quiz, starterCards, surveyQuestions } from "@/lib/ekchala/content";
import { addScore } from "@/lib/ekchala/server";
import { useItems } from "@/lib/ekchala/use-items";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { Btn, control, Empty, PageTitle, Tabs } from "@/components/ui";

export const Route = createFileRoute("/make")({ component: Make });

function Make() {
  const [tab, setTab] = useState("draw");
  return (
    <div>
      <PageTitle kicker="বানানো" title="হাতের কাজ ও খেলা।" />
      <Tabs
        value={tab}
        onChange={setTab}
        options={[
          { id: "draw", label: "আঁকা" },
          { id: "mood", label: "মুড" },
          { id: "quiz", label: "কুইজ" },
          { id: "cards", label: "কার্ড" },
          { id: "poll", label: "ভোট" },
          { id: "survey", label: "জরিপ" },
          { id: "time", label: "কালপঞ্জি" },
          { id: "tree", label: "বংশ" },
          { id: "gen", label: "জেনারেটর" },
        ]}
      />
      {tab === "draw" ? <Draw /> : null}
      {tab === "mood" ? <Mood /> : null}
      {tab === "quiz" ? <Quiz /> : null}
      {tab === "cards" ? <Cards /> : null}
      {tab === "poll" ? <Poll /> : null}
      {tab === "survey" ? <Survey /> : null}
      {tab === "time" ? <Timeline /> : null}
      {tab === "tree" ? <Tree /> : null}
      {tab === "gen" ? <Gens /> : null}
    </div>
  );
}

function Draw() {
  const ref = useRef<HTMLCanvasElement>(null);
  const drawing = useRef(false);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const ratio = window.devicePixelRatio || 1;
      canvas.width = rect.width * ratio;
      canvas.height = rect.height * ratio;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      ctx.scale(ratio, ratio);
      ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue("--color-surface");
      ctx.fillRect(0, 0, rect.width, rect.height);
    };
    resize();
  }, []);
  function pos(event: ReactPointerEvent<HTMLCanvasElement>) {
    const rect = event.currentTarget.getBoundingClientRect();
    return { x: event.clientX - rect.left, y: event.clientY - rect.top };
  }
  function stroke(event: ReactPointerEvent<HTMLCanvasElement>) {
    if (!drawing.current) return;
    const ctx = ref.current?.getContext("2d");
    if (!ctx) return;
    const { x, y } = pos(event);
    ctx.lineTo(x, y);
    ctx.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue("--color-primary");
    ctx.lineWidth = 3;
    ctx.lineCap = "round";
    ctx.stroke();
  }
  return (
    <div>
      <canvas
        ref={ref}
        className="h-80 w-full touch-none rounded-md border border-line bg-surface"
        onPointerDown={(event) => {
          drawing.current = true;
          const ctx = ref.current?.getContext("2d");
          const { x, y } = pos(event);
          ctx?.beginPath();
          ctx?.moveTo(x, y);
          event.currentTarget.setPointerCapture(event.pointerId);
        }}
        onPointerMove={stroke}
        onPointerUp={() => {
          drawing.current = false;
        }}
      />
      <Btn
        kind="ghost"
        className="mt-3"
        type="button"
        onClick={() => {
          const canvas = ref.current;
          const ctx = canvas?.getContext("2d");
          if (!canvas || !ctx) return;
          ctx.setTransform(1, 0, 0, 1, 0, 0);
          ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue("--color-surface");
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        }}
      >
        মুছে ফেলুন
      </Btn>
    </div>
  );
}

const swatches = ["bg-primary", "bg-ink", "bg-line", "bg-muted"] as const;

function Mood() {
  const bag = useItems<{ word: string; tone: number }>("mood");
  const [word, setWord] = useState("");
  const [tone, setTone] = useState(0);
  return (
    <div className="max-w-xl space-y-3">
      <form
        className="flex gap-2"
        onSubmit={async (event) => {
          event.preventDefault();
          if (!word.trim()) return;
          await bag.add({ word: word.trim(), tone });
          setWord("");
        }}
      >
        <input className={control} placeholder="একটা শব্দ" value={word} onChange={(e) => setWord(e.target.value)} />
        <Btn type="submit">পিন</Btn>
      </form>
      <div className="flex gap-2">
        {swatches.map((cls, index) => (
          <button key={cls} type="button" aria-label="রং" onClick={() => setTone(index)} className={`h-11 w-11 rounded-full ${cls} ${tone === index ? "ring-2 ring-ink ring-offset-2" : ""}`} />
        ))}
      </div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {bag.items.map((item) => (
          <button key={item.id} type="button" onClick={() => bag.remove(item.id)} className={`min-h-28 rounded-md p-4 text-left text-surface ${swatches[item.tone] ?? swatches[0]}`}>
            {item.word}
          </button>
        ))}
      </div>
    </div>
  );
}

function Quiz() {
  const user = useCurrentUser();
  const [step, setStep] = useState(0);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);
  const card = quiz[step];
  if (done) {
    return (
      <div className="max-w-md space-y-3">
        <p className="text-4xl tabular-nums">{score} / {quiz.length}</p>
        <Btn
          type="button"
          disabled={!user}
          onClick={async () => {
            await addScore({ data: { displayName: user?.displayName || "নামহীন", game: "কুইজ", points: score } });
            toast("বোর্ডে উঠেছে");
          }}
        >
          বোর্ডে দিন
        </Btn>
        {!user ? <p className="text-muted">বোর্ডে দিতে অ্যাকাউন্ট লাগে।</p> : null}
        <Btn kind="ghost" type="button" onClick={() => { setStep(0); setScore(0); setDone(false); }}>আবার</Btn>
      </div>
    );
  }
  return (
    <div className="max-w-xl">
      <p className="text-sm text-muted">{step + 1} / {quiz.length}</p>
      <h2 className="mt-2 text-3xl">{card.q}</h2>
      <div className="mt-4 grid gap-2">
        {card.options.map((option, index) => (
          <button
            key={option}
            type="button"
            className="min-h-11 rounded-md border border-line bg-surface px-4 text-left"
            onClick={() => {
              const next = score + (index === card.a ? 1 : 0);
              if (step + 1 >= quiz.length) {
                setScore(next);
                setDone(true);
              } else {
                setScore(next);
                setStep(step + 1);
              }
            }}
          >
            {option}
          </button>
        ))}
      </div>
    </div>
  );
}

function Cards() {
  const bag = useItems<{ front: string; back: string }>("card");
  const [front, setFront] = useState("");
  const [back, setBack] = useState("");
  const [i, setI] = useState(0);
  const [flip, setFlip] = useState(false);
  const deck = bag.items.length ? bag.items : starterCards.map((card, index) => ({ ...card, id: `s${index}` }));
  const card = deck[i % deck.length];
  return (
    <div className="max-w-md space-y-3">
      <button type="button" onClick={() => setFlip((v) => !v)} className="flex min-h-48 w-full items-center justify-center rounded-md border border-line bg-surface p-6 text-center text-3xl">
        {flip ? card.back : card.front}
      </button>
      <div className="flex gap-2">
        <Btn kind="ghost" type="button" onClick={() => { setFlip(false); setI((n) => (n + 1) % deck.length); }}>পরেরটা</Btn>
      </div>
      <form
        className="space-y-2"
        onSubmit={async (event) => {
          event.preventDefault();
          if (!front.trim() || !back.trim()) return;
          await bag.add({ front: front.trim(), back: back.trim() });
          setFront("");
          setBack("");
        }}
      >
        <input className={control} placeholder="সামনে" value={front} onChange={(e) => setFront(e.target.value)} />
        <input className={control} placeholder="পেছনে" value={back} onChange={(e) => setBack(e.target.value)} />
        <Btn type="submit">নিজের কার্ড</Btn>
      </form>
    </div>
  );
}

function Poll() {
  const bag = useItems<{ question: string; options: { label: string; votes: number }[] }>("poll");
  const [question, setQuestion] = useState("");
  const [opts, setOpts] = useState("হ্যাঁ, না");
  return (
    <div className="max-w-xl space-y-4">
      <form
        className="space-y-2"
        onSubmit={async (event) => {
          event.preventDefault();
          const options = opts.split(",").map((part) => part.trim()).filter(Boolean).map((label) => ({ label, votes: 0 }));
          if (!question.trim() || options.length < 2) return;
          await bag.add({ question: question.trim(), options });
          setQuestion("");
        }}
      >
        <input className={control} placeholder="প্রশ্ন" value={question} onChange={(e) => setQuestion(e.target.value)} />
        <input className={control} placeholder="অপশন, কমা দিয়ে" value={opts} onChange={(e) => setOpts(e.target.value)} />
        <Btn type="submit">ভোট খুলুন</Btn>
      </form>
      {bag.items.length === 0 ? <Empty>একটা প্রশ্ন খুলুন।</Empty> : null}
      {bag.items.map((item) => (
        <div key={item.id} className="rounded-md border border-line bg-surface p-4">
          <h3 className="text-2xl">{item.question}</h3>
          <div className="mt-3 space-y-2">
            {item.options.map((option, index) => (
              <button
                key={option.label}
                type="button"
                className="flex min-h-11 w-full items-center justify-between rounded-md border border-line px-3"
                onClick={() => {
                  const options = item.options.map((opt, i) => (i === index ? { ...opt, votes: opt.votes + 1 } : opt));
                  bag.update(item.id, { question: item.question, options });
                }}
              >
                <span>{option.label}</span>
                <span className="tabular-nums">{option.votes}</span>
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function Survey() {
  const bag = useItems<{ answers: string[] }>("survey");
  const [answers, setAnswers] = useState<string[]>(() => surveyQuestions.map(() => ""));
  return (
    <form
      className="max-w-xl space-y-3"
      onSubmit={async (event) => {
        event.preventDefault();
        await bag.add({ answers });
        toast("জরিপ জমা");
        setAnswers(surveyQuestions.map(() => ""));
      }}
    >
      {surveyQuestions.map((question, index) => (
        <label key={question} className="block space-y-1">
          <span>{question}</span>
          <input
            className={control}
            value={answers[index]}
            onChange={(e) => setAnswers((prev) => prev.map((value, i) => (i === index ? e.target.value : value)))}
          />
        </label>
      ))}
      <Btn type="submit">জমা</Btn>
      <p className="text-sm text-muted">{bag.items.length}টা উত্তর রাখা আছে।</p>
    </form>
  );
}

function Timeline() {
  const bag = useItems<{ year: string; title: string; text: string }>("timeline");
  const [year, setYear] = useState("২০২০");
  const [title, setTitle] = useState("");
  const [text, setText] = useState("");
  return (
    <div className="max-w-xl space-y-4">
      <form
        className="space-y-2"
        onSubmit={async (event) => {
          event.preventDefault();
          if (!title.trim()) return;
          await bag.add({ year, title: title.trim(), text });
          setTitle("");
          setText("");
        }}
      >
        <input className={control} value={year} onChange={(e) => setYear(e.target.value)} />
        <input className={control} placeholder="কী হয়েছিল" value={title} onChange={(e) => setTitle(e.target.value)} />
        <input className={control} placeholder="এক লাইন" value={text} onChange={(e) => setText(e.target.value)} />
        <Btn type="submit">বসান</Btn>
      </form>
      <ol className="space-y-4 border-l border-line pl-4">
        {bag.items.map((item) => (
          <li key={item.id}>
            <p className="text-sm text-primary">{item.year}</p>
            <h3 className="text-2xl">{item.title}</h3>
            <p className="text-muted">{item.text}</p>
          </li>
        ))}
      </ol>
    </div>
  );
}

function Tree() {
  const bag = useItems<{ name: string; parent: string }>("person");
  const [name, setName] = useState("");
  const [parent, setParent] = useState("");
  const roots = bag.items.filter((item) => !item.parent);
  function kids(id: string): Array<{ id: string; name: string; parent: string }> {
    return bag.items.filter((item) => item.parent === id);
  }
  function Branch({ id, name: label }: { id: string; name: string }) {
    return (
      <li className="mt-2">
        <span>{label}</span>
        {kids(id).length ? (
          <ul className="ml-4 border-l border-line pl-3">
            {kids(id).map((child) => (
              <Branch key={child.id} id={child.id} name={child.name} />
            ))}
          </ul>
        ) : null}
      </li>
    );
  }
  return (
    <div className="max-w-xl space-y-3">
      <form
        className="space-y-2"
        onSubmit={async (event) => {
          event.preventDefault();
          if (!name.trim()) return;
          await bag.add({ name: name.trim(), parent });
          setName("");
        }}
      >
        <input className={control} placeholder="নাম" value={name} onChange={(e) => setName(e.target.value)} />
        <select className={control} value={parent} onChange={(e) => setParent(e.target.value)}>
          <option value="">কারও সন্তান নয়</option>
          {bag.items.map((item) => (
            <option key={item.id} value={item.id}>{item.name}</option>
          ))}
        </select>
        <Btn type="submit">যোগ</Btn>
      </form>
      {roots.length === 0 ? <Empty>প্রথম নামটা মূল।</Empty> : null}
      <ul>
        {roots.map((item) => (
          <Branch key={item.id} id={item.id} name={item.name} />
        ))}
      </ul>
    </div>
  );
}

function Gens() {
  const [which, setWhich] = useState("name");
  const [batch, setBatch] = useState<string[]>(names.soft.slice(0, 3));
  const [password, setPassword] = useState("");
  const [colors, setColors] = useState<string[]>(["#c4512c", "#1a1612", "#f3eee6", "#6f675c", "#e0d5c6"]);
  return (
    <div className="max-w-xl space-y-4">
      <Tabs
        value={which}
        onChange={setWhich}
        options={[
          { id: "name", label: "নাম" },
          { id: "pass", label: "পাসওয়ার্ড" },
          { id: "color", label: "রং" },
        ]}
      />
      {which === "name" ? (
        <div>
          <div className="flex gap-2">
            <Btn type="button" onClick={() => setBatch(pick(names.soft))}>নরম</Btn>
            <Btn kind="ink" type="button" onClick={() => setBatch(pick(names.sharp))}>তীক্ষ্ণ</Btn>
          </div>
          <ul className="mt-4 space-y-2 text-2xl">
            {batch.map((name) => <li key={name}>{name}</li>)}
          </ul>
        </div>
      ) : null}
      {which === "pass" ? (
        <div className="space-y-3">
          <Btn
            type="button"
            onClick={() => {
              const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
              const bytes = crypto.getRandomValues(new Uint8Array(14));
              setPassword(Array.from(bytes, (b) => alphabet[b % alphabet.length]).join(""));
            }}
          >
            বানান
          </Btn>
          <p className="break-all font-mono text-xl">{password || "—"}</p>
          <Btn kind="ghost" type="button" onClick={() => navigator.clipboard.writeText(password).then(() => toast("কপি"))}>কপি</Btn>
        </div>
      ) : null}
      {which === "color" ? (
        <div>
          <Btn
            type="button"
            onClick={() => {
              const hue = Math.floor(Math.random() * 360);
              setColors([0, 24, 48, 200, 40].map((shift, index) => {
                const h = (hue + shift) % 360;
                const light = index === 2 ? 92 : index === 4 ? 80 : 42;
                return hsl(h, 38, light);
              }));
            }}
          >
            নতুন পাতা
          </Btn>
          <div className="mt-4 grid grid-cols-5 gap-2">
            {colors.map((color) => (
              <button key={color} type="button" className="min-h-24 rounded-md" style={{ background: color }} onClick={() => navigator.clipboard.writeText(color).then(() => toast(color))} />
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
}

function pick(list: string[]) {
  return [...list].sort(() => Math.random() - 0.5).slice(0, 3);
}

function hsl(h: number, s: number, l: number) {
  const a = s / 100 * Math.min(l / 100, 1 - l / 100);
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    const c = l / 100 - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
    return Math.round(255 * c).toString(16).padStart(2, "0");
  };
  return `#${f(0)}${f(8)}${f(4)}`;
}
