import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { sampleClass, sampleSales, sampleStock } from "@/lib/ekchala/content";
import { useItems } from "@/lib/ekchala/use-items";
import { Btn, control, Empty, Field, PageTitle, Tabs, taka } from "@/components/ui";

export const Route = createFileRoute("/money")({ component: Money });

function Money() {
  const [tab, setTab] = useState("spend");
  return (
    <div>
      <PageTitle kicker="হিসাব" title="টাকা, মাপ, আর কাগজ।" />
      <Tabs
        value={tab}
        onChange={setTab}
        options={[
          { id: "spend", label: "খরচ" },
          { id: "dash", label: "ড্যাশ" },
          { id: "calc", label: "অঙ্ক" },
          { id: "paper", label: "কাগজ" },
        ]}
      />
      {tab === "spend" ? <Spend /> : null}
      {tab === "dash" ? <Dash /> : null}
      {tab === "calc" ? <Calcs /> : null}
      {tab === "paper" ? <Papers /> : null}
    </div>
  );
}

const cats = ["বাজার", "বাড়ি", "বিল", "যাতায়াত", "অন্যান্য"];

function Spend() {
  const bag = useItems<{ title: string; category: string; amount: number }>("expense");
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState(cats[0]);
  const [amount, setAmount] = useState("");
  const grouped = useMemo(() => {
    return cats.map((name) => ({
      name,
      value: bag.items.filter((item) => item.category === name).reduce((sum, item) => sum + Number(item.amount || 0), 0),
    }));
  }, [bag.items]);
  const total = grouped.reduce((sum, row) => sum + row.value, 0);
  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_18rem]">
      <div>
        <p className="mb-3 tabular-nums text-3xl">{taka(total)}</p>
        <div className="h-56 w-full text-muted">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={grouped}>
              <XAxis dataKey="name" stroke="currentColor" fontSize={12} />
              <YAxis stroke="currentColor" fontSize={12} />
              <Tooltip />
              <Bar dataKey="value" fill="var(--color-primary)" radius={4} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        {bag.items.length === 0 ? <Empty>খরচ যোগ করলে বার উঠবে।</Empty> : null}
        <ul className="mt-4 space-y-2">
          {bag.items.map((item) => (
            <li key={item.id} className="flex items-center justify-between gap-2 border-b border-line py-2">
              <span>{item.title}<span className="text-muted"> · {item.category}</span></span>
              <span className="tabular-nums">{taka(item.amount)}</span>
              <button type="button" className="min-h-11 text-sm text-primary" onClick={() => bag.remove(item.id)}>মুছুন</button>
            </li>
          ))}
        </ul>
      </div>
      <form
        className="space-y-3"
        onSubmit={async (event) => {
          event.preventDefault();
          const value = Number(amount);
          if (!title.trim() || !value) return;
          await bag.add({ title: title.trim(), category, amount: value });
          setTitle("");
          setAmount("");
        }}
      >
        <Field label="কী কিনলেন">
          <input className={control} value={title} onChange={(e) => setTitle(e.target.value)} />
        </Field>
        <Field label="খাত">
          <select className={control} value={category} onChange={(e) => setCategory(e.target.value)}>
            {cats.map((cat) => <option key={cat}>{cat}</option>)}
          </select>
        </Field>
        <Field label="টাকা">
          <input className={control} inputMode="numeric" value={amount} onChange={(e) => setAmount(e.target.value)} />
        </Field>
        <Btn type="submit">যোগ</Btn>
      </form>
    </div>
  );
}

function Chart({ title, data, note }: { title: string; data: { name: string; value: number }[]; note: string }) {
  return (
    <section className="rounded-md border border-line bg-surface p-4">
      <h2 className="text-2xl">{title}</h2>
      <p className="text-sm text-muted">{note}</p>
      <div className="mt-3 h-48 text-muted">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <XAxis dataKey="name" stroke="currentColor" fontSize={12} />
            <YAxis stroke="currentColor" fontSize={12} />
            <Tooltip />
            <Bar dataKey="value" fill="var(--color-ink)" radius={4} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </section>
  );
}

function Dash() {
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Chart title="বিক্রি" data={sampleSales} note="নমুনা — দোকানের মাস।" />
      <Chart title="স্টক" data={sampleStock} note="নমুনা — এখন কতটা আছে।" />
      <Chart title="ক্লাস" data={sampleClass} note="নমুনা — ছাত্রের নম্বর।" />
    </div>
  );
}

function Calcs() {
  const [which, setWhich] = useState("emi");
  return (
    <div>
      <Tabs
        value={which}
        onChange={setWhich}
        options={[
          { id: "emi", label: "ইএমআই" },
          { id: "bmi", label: "বিএমআই" },
          { id: "unit", label: "একক" },
          { id: "budget", label: "বাজেট" },
        ]}
      />
      {which === "emi" ? <Emi /> : null}
      {which === "bmi" ? <Bmi /> : null}
      {which === "unit" ? <Units /> : null}
      {which === "budget" ? <Budget /> : null}
    </div>
  );
}

function Emi() {
  const [p, setP] = useState("500000");
  const [rate, setRate] = useState("9");
  const [months, setMonths] = useState("60");
  const principal = Number(p) || 0;
  const n = Number(months) || 0;
  const yearly = Number(rate) || 0;
  const r = yearly / 12 / 100;
  const emi = n <= 0 ? 0 : r === 0 ? principal / n : (principal * r * (1 + r) ** n) / ((1 + r) ** n - 1);
  return (
    <div className="grid max-w-xl gap-3">
      <Field label="আসল"><input className={control} value={p} onChange={(e) => setP(e.target.value)} /></Field>
      <Field label="বার্ষিক সুদ %"><input className={control} value={rate} onChange={(e) => setRate(e.target.value)} /></Field>
      <Field label="মাস"><input className={control} value={months} onChange={(e) => setMonths(e.target.value)} /></Field>
      <p className="text-3xl tabular-nums">মাসে {taka(emi)}</p>
      <p className="text-muted">মোট {taka(emi * n)} · সুদ {taka(emi * n - principal)}</p>
    </div>
  );
}

function Bmi() {
  const [kg, setKg] = useState("64");
  const [cm, setCm] = useState("168");
  const m = (Number(cm) || 0) / 100;
  const bmi = m ? (Number(kg) || 0) / (m * m) : 0;
  const word = bmi < 18.5 ? "কম" : bmi < 25 ? "মাঝারি" : bmi < 30 ? "বেশি" : "অনেক বেশি";
  return (
    <div className="grid max-w-xl gap-3">
      <Field label="কেজি"><input className={control} value={kg} onChange={(e) => setKg(e.target.value)} /></Field>
      <Field label="সেন্টিমিটার"><input className={control} value={cm} onChange={(e) => setCm(e.target.value)} /></Field>
      <p className="text-3xl tabular-nums">{bmi.toFixed(1)} · {word}</p>
    </div>
  );
}

function Units() {
  const [km, setKm] = useState("5");
  const [kg, setKg] = useState("1");
  const [c, setC] = useState("30");
  return (
    <div className="grid max-w-xl gap-4">
      <Field label="কিলোমিটার">
        <input className={control} value={km} onChange={(e) => setKm(e.target.value)} />
        <p className="tabular-nums text-muted">{((Number(km) || 0) * 0.621371).toFixed(2)} মাইল</p>
      </Field>
      <Field label="কিলোগ্রাম">
        <input className={control} value={kg} onChange={(e) => setKg(e.target.value)} />
        <p className="tabular-nums text-muted">{((Number(kg) || 0) * 2.20462).toFixed(2)} পাউন্ড</p>
      </Field>
      <Field label="সেলসিয়াস">
        <input className={control} value={c} onChange={(e) => setC(e.target.value)} />
        <p className="tabular-nums text-muted">{((Number(c) || 0) * 9) / 5 + 32} ফারেনহাইট</p>
      </Field>
    </div>
  );
}

function Budget() {
  const [income, setIncome] = useState("40000");
  const [rent, setRent] = useState("15000");
  const [food, setFood] = useState("10000");
  const [rest, setRest] = useState("5000");
  const left = (Number(income) || 0) - (Number(rent) || 0) - (Number(food) || 0) - (Number(rest) || 0);
  return (
    <div className="grid max-w-xl gap-3">
      <Field label="আয়"><input className={control} value={income} onChange={(e) => setIncome(e.target.value)} /></Field>
      <Field label="বাড়ি"><input className={control} value={rent} onChange={(e) => setRent(e.target.value)} /></Field>
      <Field label="বাজার"><input className={control} value={food} onChange={(e) => setFood(e.target.value)} /></Field>
      <Field label="অন্য"><input className={control} value={rest} onChange={(e) => setRest(e.target.value)} /></Field>
      <p className="text-3xl tabular-nums">বাকি {taka(left)}</p>
    </div>
  );
}

function Papers() {
  const [kind, setKind] = useState("ইনভয়েস");
  const [who, setWho] = useState("");
  const [line, setLine] = useState("কাজ");
  const [amount, setAmount] = useState("5000");
  const bag = useItems<{ kind: string; who: string; line: string; amount: number }>("paper");
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <form
        className="space-y-3"
        onSubmit={async (event) => {
          event.preventDefault();
          await bag.add({ kind, who, line, amount: Number(amount) || 0 });
        }}
      >
        <Tabs
          value={kind}
          onChange={setKind}
          options={[
            { id: "ইনভয়েস", label: "ইনভয়েস" },
            { id: "কোটেশন", label: "কোটেশন" },
            { id: "রেজুমে", label: "রেজুমে" },
          ]}
        />
        <Field label={kind === "রেজুমে" ? "নাম" : "কার জন্য"}>
          <input className={control} value={who} onChange={(e) => setWho(e.target.value)} />
        </Field>
        <Field label={kind === "রেজুমে" ? "কাজের লাইন" : "বিবরণ"}>
          <input className={control} value={line} onChange={(e) => setLine(e.target.value)} />
        </Field>
        {kind === "রেজুমে" ? null : (
          <Field label="টাকা"><input className={control} value={amount} onChange={(e) => setAmount(e.target.value)} /></Field>
        )}
        <div className="flex gap-2">
          <Btn type="submit">রাখুন</Btn>
          <Btn kind="ghost" type="button" onClick={() => window.print()}>প্রিন্ট</Btn>
        </div>
      </form>
      <article className="rounded-md border border-line bg-surface p-6">
        <p className="text-sm text-primary">{kind}</p>
        <h2 className="text-4xl">{who || "নাম"}</h2>
        <p className="mt-3">{line}</p>
        {kind === "রেজুমে" ? null : <p className="mt-4 text-2xl tabular-nums">{taka(Number(amount) || 0)}</p>}
      </article>
    </div>
  );
}
