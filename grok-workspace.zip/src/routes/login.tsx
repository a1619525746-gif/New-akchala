import { createFileRoute, Link } from "@tanstack/react-router";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const { user, isPending } = useCurrentUserState();
  return (
    <main className="grid min-h-screen place-items-center bg-bg px-6 text-ink">
      <div className="w-full max-w-md space-y-4">
        <p className="text-sm text-primary">একচালা</p>
        <h1 className="text-4xl">অ্যাকাউন্ট</h1>
        {isPending ? <div className="h-16 animate-pulse rounded-md bg-line" /> : null}
        {!isPending && user ? (
          <p className="text-lg">
            আপনি ঢুকে আছেন{user.displayName ? `, ${user.displayName}` : ""}। প্রোফাইল, হিসাব আর শেয়ার এই নামেই জমা হয়।
          </p>
        ) : null}
        {!isPending && !user ? (
          <p className="text-lg text-muted">
            Grok-এর ভেতর থেকে খুললে অ্যাকাউন্ট নিজে থেকেই খোলে — আলাদা বাটন লাগে না। না খুললে এই ব্রাউজারেই সব কাজ সেভ থাকে, পরে অ্যাকাউন্ট ধরলে সেগুলো উঠে আসে।
          </p>
        ) : null}
        <Link to="/" className="inline-flex min-h-11 items-center text-primary">
          ঘরে ফিরুন
        </Link>
      </div>
    </main>
  );
}
