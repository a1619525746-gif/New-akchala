import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { addScore } from "@/lib/ekchala/server";
import { useItems } from "@/lib/ekchala/use-items";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { Btn, control, Empty, PageTitle, Speak, Tabs } from "@/components/ui";

export const Route = createFileRoute("/work")({ component: Work });

function Work() {
  const [tab, setTab] = useState("tasks");
  return (
    <div>
      <PageTitle kicker="কাজ" title="যা করতে হবে, যা মনে রাখতে হবে।" />
      <Tabs
        value={tab}
        onChange={setTab}
        options={[
          { id: "tasks", label: "তালিকা" },
          { id: "board", label: "বোর্ড" },
          { id: "notes", label: "নোট" },
          { id: "habits", label: "অভ্যাস" },
          { id: "focus", label: "ফোকাস" },
          { id: "cal", label: "ক্যালেন্ডার" },
          { id: "marks", label: "বুকমার্ক" },
          { id: "bell", label: "ঘণ্টা" },
        ]}
      />
      {tab === "tasks" ? <Tasks /> : null}
      {tab === "board" ? <Board /> : null}
      {tab === "notes" ? <Notes /> : null}
      {tab === "habits" ? <Habits /> : null}
      {tab === "focus" ? <Focus /> : null}
      {tab === "cal" ? <Cal /> : null}
      {tab === "marks" ? <Marks /> : null}
      {tab === "bell" ? <Bells /> : null}
    </div>
  );
}

type Task = { title: string; done: boolean; status: "todo" | "doing" | "done" };

function Tasks() {
  const bag = useItems<Task>("task");
  const [title, setTitle] = useState("");
  return (
    <div className="max-w-xl space-y-3">
      <form
        className="flex gap-2"
        onSubmit={async (event) => {
          event.preventDefault();
          if (!title.trim()) return;
          await bag.add({ title: title.trim(), done: false, status: "todo" });
          setTitle("");
        }}
      >
        <input className={control} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="নতুন কাজ" />
        <Btn type="submit">যোগ</Btn>
      </form>
      {!bag.ready ? <p className="text-muted">লোড হচ্ছে…</p> : null}
      {bag.ready && bag.items.length === 0 ? <Empty>তালিকা খালি।</Empty> : null}
      <ul className="space-y-2">
        {bag.items.map((item) => (
          <li key={item.id} className="flex items-center gap-2 rounded-md border border-line bg-surface px-3">
            <button
              type="button"
              className="min-h-11 min-w-11"
              onClick={() => bag.update(item.id, { ...item, done: !item.done, status: !item.done ? "done" : "todo" })}
            >
              {item.done ? "✓" : "○"}
            </button>
            <span className={item.done ? "text-muted line-through" : ""}>{item.title}</span>
            <button type="button" className="ml-auto min-h-11 text-sm text-primary" onClick={() => bag.remove(item.id)}>
              মুছুন
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

const cols = [
  { id: "todo", label: "করব" },
  { id: "doing", label: "করছি" },
  { id: "done", label: "হয়ে গেছে" },
] as const;

function Board() {
  const bag = useItems<Task>("task");
  return (
    <div className="grid gap-3 lg:grid-cols-3">
      {cols.map((col) => (
        <section key={col.id} className="rounded-md border border-line bg-surface p-3">
          <h2 className="text-2xl">{col.label}</h2>
          <ul className="mt-3 space-y-2">
            {bag.items.filter((item) => item.status === col.id).map((item) => (
              <li key={item.id} className="rounded-md border border-line p-3">
                <p>{item.title}</p>
                <div className="mt-2 flex gap-2">
                  {cols.filter((next) => next.id !== item.status).map((next) => (
                    <button
                      key={next.id}
                      type="button"
                      className="min-h-11 text-sm text-primary"
                      onClick={() => bag.update(item.id, { ...item, status: next.id, done: next.id === "done" })}
                    >
                      {next.label}
                    </button>
                  ))}
                </div>
              </li>
            ))}
          </ul>
        </section>
      ))}
    </div>
  );
}

function Notes() {
  const bag = useItems<{ title: string; body: string }>("note");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [open, setOpen] = useState<string | null>(null);
  const note = bag.items.find((item) => item.id === open);
  return (
    <div className="grid gap-4 lg:grid-cols-[16rem_1fr]">
      <div>
        <form
          className="space-y-2"
          onSubmit={async (event) => {
            event.preventDefault();
            if (!title.trim()) return;
            await bag.add({ title: title.trim(), body });
            setTitle("");
            setBody("");
          }}
        >
          <input className={control} placeholder="শিরোনাম" value={title} onChange={(e) => setTitle(e.target.value)} />
          <textarea className={`${control} min-h-24`} placeholder="লেখা" value={body} onChange={(e) => setBody(e.target.value)} />
          <Btn type="submit">রাখুন</Btn>
        </form>
        <ul className="mt-3 space-y-2">
          {bag.items.map((item) => (
            <li key={item.id}>
              <button type="button" className="min-h-11 text-left" onClick={() => setOpen(item.id)}>
                {item.title}
              </button>
            </li>
          ))}
        </ul>
      </div>
      {note ? (
        <article className="rounded-md border border-line bg-surface p-5">
          <h2 className="text-3xl">{note.title}</h2>
          <p className="mt-3 whitespace-pre-wrap">{note.body}</p>
          <div className="mt-4 flex gap-2">
            <Speak text={`${note.title}. ${note.body}`} />
            <Btn kind="ghost" type="button" onClick={() => bag.remove(note.id)}>মুছুন</Btn>
          </div>
        </article>
      ) : (
        <Empty>একটা নোট খুলুন, অথবা নতুন লিখুন।</Empty>
      )}
    </div>
  );
}

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

function Habits() {
  const bag = useItems<{ name: string; dates: string[] }>("habit");
  const [name, setName] = useState("");
  const today = todayKey();
  return (
    <div className="max-w-xl space-y-3">
      <form
        className="flex gap-2"
        onSubmit={async (event) => {
          event.preventDefault();
          if (!name.trim()) return;
          await bag.add({ name: name.trim(), dates: [] });
          setName("");
        }}
      >
        <input className={control} placeholder="অভ্যাস" value={name} onChange={(e) => setName(e.target.value)} />
        <Btn type="submit">যোগ</Btn>
      </form>
      {bag.items.length === 0 ? <Empty>যেমন: হাঁটা, জল, পড়া।</Empty> : null}
      <ul className="space-y-2">
        {bag.items.map((item) => {
          const on = item.dates.includes(today);
          return (
            <li key={item.id} className="flex items-center gap-3 rounded-md border border-line bg-surface px-3">
              <button
                type="button"
                className="min-h-11"
                onClick={() =>
                  bag.update(item.id, {
                    name: item.name,
                    dates: on ? item.dates.filter((d) => d !== today) : [...item.dates, today],
                  })
                }
              >
                {on ? "আজ হয়েছে" : "আজ টিক"}
              </button>
              <span>{item.name}</span>
              <span className="ml-auto tabular-nums text-muted">{item.dates.length} দিন</span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function Focus() {
  const user = useCurrentUser();
  const [left, setLeft] = useState(25 * 60);
  const [run, setRun] = useState(false);
  useEffect(() => {
    if (!run) return;
    const timer = setInterval(() => {
      setLeft((value) => {
        if (value <= 1) {
          setRun(false);
          toast("পঁচিশ মিনিট শেষ");
          return 0;
        }
        return value - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [run]);
  const m = String(Math.floor(left / 60)).padStart(2, "0");
  const s = String(left % 60).padStart(2, "0");
  return (
    <div className="max-w-md rounded-md border border-line bg-surface p-8 text-center">
      <p className="font-display text-6xl tabular-nums">{m}:{s}</p>
      <div className="mt-6 flex justify-center gap-2">
        <Btn type="button" onClick={() => setRun((v) => !v)}>{run ? "থামুন" : "শুরু"}</Btn>
        <Btn kind="ghost" type="button" onClick={() => { setRun(false); setLeft(25 * 60); }}>রিসেট</Btn>
      </div>
      <Btn
        kind="ink"
        className="mt-4"
        type="button"
        disabled={!user || left > 0}
        onClick={async () => {
          await addScore({
            data: { displayName: user?.displayName || "অতিথি", game: "ফোকাস", points: 25 },
          });
          toast("বোর্ডে উঠেছে");
          setLeft(25 * 60);
        }}
      >
        শেষ হলে বোর্ডে দিন
      </Btn>
    </div>
  );
}

function Cal() {
  const bag = useItems<{ title: string; day: string }>("event");
  const [cursor, setCursor] = useState(() => new Date());
  const [title, setTitle] = useState("");
  const [day, setDay] = useState(todayKey());
  const year = cursor.getFullYear();
  const month = cursor.getMonth();
  const first = new Date(year, month, 1).getDay();
  const days = new Date(year, month + 1, 0).getDate();
  const label = new Intl.DateTimeFormat("bn-BD", { month: "long", year: "numeric" }).format(cursor);
  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_16rem]">
      <div>
        <div className="mb-3 flex items-center justify-between">
          <Btn kind="ghost" type="button" onClick={() => setCursor(new Date(year, month - 1, 1))}>আগে</Btn>
          <h2 className="text-2xl">{label}</h2>
          <Btn kind="ghost" type="button" onClick={() => setCursor(new Date(year, month + 1, 1))}>পরে</Btn>
        </div>
        <div className="grid grid-cols-7 gap-1 text-center text-sm">
          {Array.from({ length: first }).map((_, i) => (
            <div key={`e${i}`} />
          ))}
          {Array.from({ length: days }).map((_, i) => {
            const date = `${year}-${String(month + 1).padStart(2, "0")}-${String(i + 1).padStart(2, "0")}`;
            const count = bag.items.filter((item) => item.day === date).length;
            return (
              <button
                key={date}
                type="button"
                onClick={() => setDay(date)}
                className={`min-h-11 rounded-md ${day === date ? "bg-ink text-surface" : "bg-surface"}`}
              >
                {i + 1}
                {count ? <span className="block text-primary">•</span> : null}
              </button>
            );
          })}
        </div>
      </div>
      <form
        className="space-y-2"
        onSubmit={async (event) => {
          event.preventDefault();
          if (!title.trim()) return;
          await bag.add({ title: title.trim(), day });
          setTitle("");
        }}
      >
        <input className={control} type="date" value={day} onChange={(e) => setDay(e.target.value)} />
        <input className={control} placeholder="কী হবে" value={title} onChange={(e) => setTitle(e.target.value)} />
        <Btn type="submit">দিনে রাখুন</Btn>
        <ul className="space-y-2 pt-2">
          {bag.items.filter((item) => item.day === day).map((item) => (
            <li key={item.id} className="flex justify-between gap-2">
              <span>{item.title}</span>
              <button type="button" className="text-primary" onClick={() => bag.remove(item.id)}>মুছুন</button>
            </li>
          ))}
        </ul>
      </form>
    </div>
  );
}

function Marks() {
  const bag = useItems<{ title: string; url: string }>("bookmark");
  const [title, setTitle] = useState("");
  const [url, setUrl] = useState("");
  return (
    <div className="max-w-xl space-y-3">
      <form
        className="space-y-2"
        onSubmit={async (event) => {
          event.preventDefault();
          if (!title.trim() || !url.trim()) return;
          const href = url.startsWith("http") ? url.trim() : `https://${url.trim()}`;
          await bag.add({ title: title.trim(), url: href });
          setTitle("");
          setUrl("");
        }}
      >
        <input className={control} placeholder="নাম" value={title} onChange={(e) => setTitle(e.target.value)} />
        <input className={control} placeholder="লিংক" value={url} onChange={(e) => setUrl(e.target.value)} />
        <Btn type="submit">রাখুন</Btn>
      </form>
      {bag.items.length === 0 ? <Empty>পড়ার লিংক এখানে।</Empty> : null}
      <ul className="space-y-2">
        {bag.items.map((item) => (
          <li key={item.id} className="flex items-center gap-3">
            <a className="min-h-11 text-primary" href={item.url} target="_blank" rel="noreferrer">{item.title}</a>
            <button type="button" className="ml-auto text-sm" onClick={() => bag.remove(item.id)}>মুছুন</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Bells() {
  const bag = useItems<{ title: string; when: string; acked: boolean }>("reminder");
  const [title, setTitle] = useState("");
  const [when, setWhen] = useState("");
  const [, tick] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => tick((n) => n + 1), 30000);
    return () => clearInterval(timer);
  }, []);
  const due = bag.items.filter((item) => !item.acked && item.when && new Date(item.when).getTime() <= Date.now());
  return (
    <div className="max-w-xl space-y-3">
      <p className="text-muted">সময় হলে এই পাতায় নোটিশ আসে। ব্রাউজার বন্ধ থাকলে আসবে না — এটা ঘরের ঘড়ি, ফোনের অ্যালার্ম নয়।</p>
      {due.map((item) => (
        <div key={item.id} className="flex items-center justify-between gap-3 rounded-md bg-ink px-4 py-3 text-surface">
          <span>সময় হয়েছে: {item.title}</span>
          <button type="button" className="min-h-11" onClick={() => bag.update(item.id, { ...item, acked: true })}>দেখেছি</button>
        </div>
      ))}
      <form
        className="space-y-2"
        onSubmit={async (event) => {
          event.preventDefault();
          if (!title.trim() || !when) return;
          await bag.add({ title: title.trim(), when, acked: false });
          setTitle("");
        }}
      >
        <input className={control} placeholder="কী মনে করাবে" value={title} onChange={(e) => setTitle(e.target.value)} />
        <input className={control} type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)} />
        <Btn type="submit">ঘণ্টা রাখুন</Btn>
      </form>
      <ul className="space-y-2">
        {bag.items.map((item) => (
          <li key={item.id} className="flex justify-between gap-2 text-sm">
            <span className={item.acked ? "text-muted" : ""}>{item.title} · {item.when.replace("T", " ")}</span>
            <button type="button" className="text-primary" onClick={() => bag.remove(item.id)}>মুছুন</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
