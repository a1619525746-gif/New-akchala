import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/")({ component: Home });

const rooms = [
  { to: "/sites", kicker: "সাইট", title: "দোকান থেকে নিমন্ত্রণ", text: "দশ রকম ব্যবসা, পোর্টফোলিও, পত্রিকা, দোকান, আর এক পাতার আমন্ত্রণ।" },
  { to: "/work", kicker: "কাজ", title: "তালিকা, নোট, ঘড়ি", text: "কানবান, অভ্যাস, পোমোডোরো, ক্যালেন্ডার, বুকমার্ক, রিমাইন্ডার।" },
  { to: "/money", kicker: "হিসাব", title: "টাকা ও কাগজ", text: "খরচের চার্ট, ইএমআই, বিএমআই, একক, ইনভয়েস, কোটেশন, রেজুমে।" },
  { to: "/make", kicker: "বানানো", title: "আঁকা, কুইজ, ভোট", text: "ক্যানভাস, মুড, ফ্ল্যাশকার্ড, জরিপ, কালপঞ্জি, বংশতালিকা, নাম ও রং।" },
  { to: "/day", kicker: "দিন", title: "আবহাওয়া, রান্না, পথ", text: "আজকের আকাশ, রেসিপি, আর সপ্তাহের খাবার-পড়ার পরিকল্পনা।" },
  { to: "/desk", kicker: "ডেস্ক", title: "ক্যালেন্ডার ও ড্রাইভ", text: "Grok-এ জোড়া থাকলে সামনের সাত দিন আর ফাইলের খোঁজ।" },
] as const;

function Home() {
  const today = new Intl.DateTimeFormat("bn-BD", { dateStyle: "full" }).format(new Date());
  return (
    <div className="space-y-10">
      <header className="border-b border-line pb-8">
        <p className="text-sm text-muted">{today}</p>
        <h1 className="mt-3 max-w-3xl text-5xl leading-none sm:text-7xl">সব ঘর এক ছাদে।</h1>
        <p className="mt-4 max-w-2xl text-lg text-muted">
          ব্যবসার পাতা, নিজের খাতা, হিসাব, কুইজ, আর শেয়ার — আলাদা সাইট নয়। একচালা একটাই জায়গা। অ্যাকাউন্ট খোলা থাকলে ডেটা ডিভাইস পেরোয়।
        </p>
      </header>
      <div className="grid gap-px overflow-hidden rounded-md border border-line bg-line sm:grid-cols-2 lg:grid-cols-3">
        {rooms.map((room) => (
          <Link key={room.to} to={room.to} className="flex min-h-44 flex-col bg-surface p-5 hover:bg-bg">
            <span className="text-sm text-primary">{room.kicker}</span>
            <span className="mt-3 font-display text-3xl">{room.title}</span>
            <span className="mt-2 text-muted">{room.text}</span>
          </Link>
        ))}
      </div>
      <section className="grid gap-6 border-t border-line pt-6 sm:grid-cols-3">
        <Link to="/board" className="block">
          <h2 className="text-2xl">বোর্ড</h2>
          <p className="mt-2 text-muted">কুইজ আর ফোকাস ঘড়ির স্কোর। নাম সহ।</p>
        </Link>
        <Link to="/share" className="block">
          <h2 className="text-2xl">শেয়ার</h2>
          <p className="mt-2 text-muted">একটা লেখা অন্য লগ-ইন করা মানুষকে পাঠান।</p>
        </Link>
        <Link to="/me" className="block">
          <h2 className="text-2xl">আমি</h2>
          <p className="mt-2 text-muted">প্রোফাইল। এই নামেই বোর্ডে উঠবেন।</p>
        </Link>
      </section>
    </div>
  );
}
