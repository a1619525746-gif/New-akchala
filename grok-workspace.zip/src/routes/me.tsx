import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { SignInGate } from "@/lib/auth/gates";
import { getProfile, saveProfile } from "@/lib/ekchala/server";
import { Btn, control, Field, PageTitle } from "@/components/ui";

export const Route = createFileRoute("/me")({ component: Me });

function Me() {
  return (
    <div>
      <PageTitle kicker="আমি" title="যে নামে আপনাকে চেনা যাবে।" lede="বোর্ড আর শেয়ার এই নাম ব্যবহার করে। Grok থেকে খুললে অ্যাকাউন্ট নিজেই থাকে।" />
      <SignInGate fallback={<p className="max-w-md text-muted">এই ব্রাউজারে আপনি অতিথি। Grok-এর ভেতর থেকে খুললে প্রোফাইল খোলে।</p>}>
        <ProfileForm />
      </SignInGate>
    </div>
  );
}

function ProfileForm() {
  const [displayName, setDisplayName] = useState("");
  const [city, setCity] = useState("");
  const [about, setAbout] = useState("");
  const [ready, setReady] = useState(false);
  useEffect(() => {
    let cancel = false;
    getProfile()
      .then((profile) => {
        if (cancel) return;
        setDisplayName(profile.displayName);
        setCity(profile.city);
        setAbout(profile.about);
      })
      .catch(() => undefined)
      .finally(() => {
        if (!cancel) setReady(true);
      });
    return () => {
      cancel = true;
    };
  }, []);
  if (!ready) return <p className="text-muted">লোড হচ্ছে…</p>;
  return (
    <form
      className="max-w-md space-y-3"
      onSubmit={async (event) => {
        event.preventDefault();
        await saveProfile({ data: { displayName, city, about } });
        toast("প্রোফাইল রাখা হয়েছে");
      }}
    >
      <Field label="নাম"><input className={control} value={displayName} onChange={(e) => setDisplayName(e.target.value)} /></Field>
      <Field label="শহর"><input className={control} value={city} onChange={(e) => setCity(e.target.value)} /></Field>
      <Field label="নিজের কথা"><textarea className={`${control} min-h-28`} value={about} onChange={(e) => setAbout(e.target.value)} /></Field>
      <Btn type="submit">রাখুন</Btn>
    </form>
  );
}
