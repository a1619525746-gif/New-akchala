import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";

const KINDS = [
  "task",
  "note",
  "habit",
  "bookmark",
  "event",
  "expense",
  "card",
  "poll",
  "timeline",
  "person",
  "plan",
  "reminder",
  "order",
  "wait",
  "mood",
  "paper",
  "survey",
] as const;

const kindSchema = z.enum(KINDS);

export const listItems = createServerFn({ method: "GET" })
  .validator((kind: unknown) => kindSchema.parse(kind))
  .middleware([authMiddleware])
  .handler(async ({ context, data: kind }) => {
    const sql = await getSql();
    return sql<{ id: number; payload: string }>`
      select id, payload from items
      where user_id = ${context.userId} and kind = ${kind}
      order by id desc
      limit 200
    `;
  });

export const addItem = createServerFn({ method: "POST" })
  .validator((input: unknown) =>
    z
      .object({
        kind: kindSchema,
        payload: z.string().min(2).max(20000),
      })
      .parse(input),
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<{ id: number }>`
      insert into items (user_id, kind, payload)
      values (${context.userId}, ${data.kind}, ${data.payload})
      returning id
    `;
    return rows[0];
  });

export const updateItem = createServerFn({ method: "POST" })
  .validator((input: unknown) =>
    z
      .object({
        id: z.number().int().positive(),
        payload: z.string().min(2).max(20000),
      })
      .parse(input),
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`
      update items set payload = ${data.payload}
      where id = ${data.id} and user_id = ${context.userId}
    `;
    return { ok: true };
  });

export const deleteItem = createServerFn({ method: "POST" })
  .validator((id: unknown) => z.number().int().positive().parse(id))
  .middleware([authMiddleware])
  .handler(async ({ context, data: id }) => {
    const sql = await getSql();
    await sql`delete from items where id = ${id} and user_id = ${context.userId}`;
    return { ok: true };
  });

const profileSchema = z.object({
  displayName: z.string().max(80),
  city: z.string().max(80),
  about: z.string().max(500),
});

export const getProfile = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql<{ display_name: string; city: string; about: string }>`
      select display_name, city, about from profiles where user_id = ${context.userId}
    `;
    const row = rows[0];
    return {
      displayName: row?.display_name ?? "",
      city: row?.city ?? "",
      about: row?.about ?? "",
    };
  });

export const saveProfile = createServerFn({ method: "POST" })
  .validator((input: unknown) => profileSchema.parse(input))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`
      insert into profiles (user_id, display_name, city, about)
      values (${context.userId}, ${data.displayName}, ${data.city}, ${data.about})
      on conflict (user_id) do update
      set display_name = ${data.displayName}, city = ${data.city}, about = ${data.about}
    `;
    return { ok: true };
  });

export const listScores = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async () => {
    const sql = await getSql();
    return sql<{ display_name: string; game: string; points: number; created_at: string }>`
      select display_name, game, points, created_at::text as created_at
      from scores
      order by points desc, id desc
      limit 40
    `;
  });

export const addScore = createServerFn({ method: "POST" })
  .validator((input: unknown) =>
    z
      .object({
        displayName: z.string().min(1).max(80),
        game: z.string().min(1).max(40),
        points: z.number().int().min(0).max(100000),
      })
      .parse(input),
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`
      insert into scores (user_id, display_name, game, points)
      values (${context.userId}, ${data.displayName}, ${data.game}, ${data.points})
    `;
    return { ok: true };
  });

export const createShare = createServerFn({ method: "POST" })
  .validator((input: unknown) =>
    z
      .object({
        title: z.string().min(1).max(120),
        body: z.string().min(1).max(8000),
      })
      .parse(input),
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const { randomBytes } = await import("node:crypto");
    const sql = await getSql();
    const code = randomBytes(4).toString("hex");
    await sql`
      insert into shares (code, user_id, title, body)
      values (${code}, ${context.userId}, ${data.title}, ${data.body})
    `;
    return { code };
  });

export const listMyShares = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    return sql<{ code: string; title: string }>`
      select code, title from shares
      where user_id = ${context.userId}
      order by created_at desc
      limit 30
    `;
  });

export const readShare = createServerFn({ method: "GET" })
  .validator((code: unknown) => z.string().regex(/^[a-f0-9]{8}$/).parse(code))
  .middleware([authMiddleware])
  .handler(async ({ data: code }) => {
    const sql = await getSql();
    const rows = await sql<{ title: string; body: string }>`
      select title, body from shares where code = ${code}
    `;
    return rows[0] ?? null;
  });

export const deleteShare = createServerFn({ method: "POST" })
  .validator((code: unknown) => z.string().regex(/^[a-f0-9]{8}$/).parse(code))
  .middleware([authMiddleware])
  .handler(async ({ context, data: code }) => {
    const sql = await getSql();
    await sql`delete from shares where code = ${code} and user_id = ${context.userId}`;
    return { ok: true };
  });

type DeskBlock = {
  ok: boolean;
  message: string;
  loginRequired: boolean;
  loginUrl?: string;
  pending: boolean;
  rows: { title: string; meta: string }[];
};

function asRows(data: unknown): { title: string; meta: string }[] {
  const obj = data && typeof data === "object" ? (data as Record<string, unknown>) : null;
  const list = Array.isArray(data)
    ? data
    : obj && Array.isArray(obj.items)
      ? obj.items
      : obj && Array.isArray(obj.events)
        ? obj.events
        : obj && Array.isArray(obj.files)
          ? obj.files
          : obj && Array.isArray(obj.results)
            ? obj.results
            : [];
  return list.slice(0, 8).map((item) => {
    const row = item && typeof item === "object" ? (item as Record<string, unknown>) : {};
    const start = row.start && typeof row.start === "object" ? (row.start as Record<string, unknown>) : {};
    const title = String(row.summary || row.name || row.title || "আইটেম");
    const meta = String(start.dateTime || start.date || row.modifiedTime || row.mimeType || "");
    return { title, meta };
  });
}

export const fetchDesk = createServerFn({ method: "POST" })
  .validator((input: unknown) =>
    z.object({ driveQuery: z.string().max(80) }).parse(input),
  )
  .handler(async ({ data }) => {
    const empty = (message: string): DeskBlock => ({
      ok: false,
      message,
      loginRequired: false,
      pending: false,
      rows: [],
    });
    try {
      const { callTool } = await import("@/lib/app-data/client.server");
      const { classifyCallToolError } = await import("@/lib/app-data/errors");
      const { ConnectorType, GoogleCalendarTools, GoogleDriveTools } = await import(
        "@/lib/app-data"
      );
      const now = new Date();
      const end = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
      const pack = (result: {
        ok: boolean;
        data: unknown;
        errorMessage?: string;
        loginRequired?: boolean;
        loginUrl?: string;
        pending?: boolean;
      }): DeskBlock => {
        if (result.ok) {
          return {
            ok: true,
            message: "",
            loginRequired: false,
            pending: false,
            rows: asRows(result.data),
          };
        }
        const classified = classifyCallToolError(result);
        return {
          ok: false,
          message: classified?.message ?? "লোড হয়নি।",
          loginRequired: classified?.kind === "login",
          loginUrl: result.loginUrl,
          pending: classified?.kind === "pending",
          rows: [],
        };
      };
      const [calendar, drive] = await Promise.all([
        callTool(
          GoogleCalendarTools.search,
          {
            timeMin: now.toISOString(),
            timeMax: end.toISOString(),
            maxResults: 8,
          },
          { connectorType: ConnectorType.GoogleCalendar },
        ),
        callTool(
          GoogleDriveTools.search,
          { q: data.driveQuery.trim() || "type:document" },
          { connectorType: ConnectorType.GoogleDrive },
        ),
      ]);
      return { calendar: pack(calendar), drive: pack(drive) };
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "ক্যালেন্ডার বা ড্রাইভ এখন পাওয়া যায়নি।";
      return { calendar: empty(message), drive: empty(message) };
    }
  });
