import { useCallback, useEffect, useState } from "react";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { addItem, deleteItem, listItems, updateItem } from "@/lib/ekchala/server";

export type Row = { id: string };

function storageKey(kind: string) {
  return `ekchala:v1:${kind}`;
}

function readLocal<T>(kind: string): Array<T & Row> {
  try {
    const raw = localStorage.getItem(storageKey(kind));
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Array<T & Row>;
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function useItems<T>(kind: string) {
  const { user, isPending } = useCurrentUserState();
  const userId = user?.id ?? null;
  const [items, setItems] = useState<Array<T & Row>>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancel = false;
    if (isPending) return;
    setReady(false);
    (async () => {
      if (!userId) {
        if (!cancel) {
          setItems(readLocal<T>(kind));
          setReady(true);
        }
        return;
      }
      try {
        const rows = await listItems({ data: kind as never });
        if (cancel) return;
        let next = rows.map((row) => ({
          ...(JSON.parse(row.payload) as T),
          id: String(row.id),
        }));
        const mig = `ekchala:mig:${userId}:${kind}`;
        if (next.length === 0 && !localStorage.getItem(mig)) {
          const local = readLocal<T>(kind);
          if (local.length) {
            for (const item of local) {
              const { id: _id, ...rest } = item;
              await addItem({ data: { kind: kind as never, payload: JSON.stringify(rest) } });
            }
            localStorage.setItem(mig, "1");
            const again = await listItems({ data: kind as never });
            next = again.map((row) => ({
              ...(JSON.parse(row.payload) as T),
              id: String(row.id),
            }));
          }
        }
        if (!cancel) setItems(next);
      } catch {
        if (!cancel) setItems([]);
      } finally {
        if (!cancel) setReady(true);
      }
    })();
    return () => {
      cancel = true;
    };
  }, [userId, isPending, kind]);

  useEffect(() => {
    if (!ready || userId || isPending) return;
    localStorage.setItem(storageKey(kind), JSON.stringify(items));
  }, [items, ready, userId, isPending, kind]);

  const add = useCallback(
    async (payload: T) => {
      if (userId) {
        const row = await addItem({ data: { kind: kind as never, payload: JSON.stringify(payload) } });
        setItems((prev) => [{ ...payload, id: String(row?.id ?? Date.now()) }, ...prev]);
        return;
      }
      setItems((prev) => [{ ...payload, id: crypto.randomUUID() }, ...prev]);
    },
    [userId, kind],
  );

  const update = useCallback(
    async (id: string, payload: T) => {
      setItems((prev) => prev.map((item) => (item.id === id ? { ...payload, id } : item)));
      const numeric = Number(id);
      if (userId && Number.isInteger(numeric) && numeric > 0) {
        await updateItem({ data: { id: numeric, payload: JSON.stringify(payload) } });
      }
    },
    [userId],
  );

  const remove = useCallback(
    async (id: string) => {
      setItems((prev) => prev.filter((item) => item.id !== id));
      const numeric = Number(id);
      if (userId && Number.isInteger(numeric) && numeric > 0) {
        await deleteItem({ data: numeric });
      }
    },
    [userId],
  );

  return { items, ready, add, update, remove, signedIn: Boolean(userId), isPending };
}
