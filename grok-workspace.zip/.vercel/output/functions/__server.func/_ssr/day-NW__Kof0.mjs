import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as PageTitle, l as control, n as Empty, o as Tabs, t as Btn } from "./ui-CrG7kmAz.mjs";
import { l as recipes } from "./content-e_t1AhxR.mjs";
import { t as useItems } from "./use-items-eJaJsOwm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/day-NW__Kof0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Day() {
	const [tab, setTab] = (0, import_react.useState)("sky");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
			kicker: "দিন",
			title: "আকাশ, হাঁড়ি, আর সপ্তাহ।"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
			value: tab,
			onChange: setTab,
			options: [
				{
					id: "sky",
					label: "আবহাওয়া"
				},
				{
					id: "cook",
					label: "রেসিপি"
				},
				{
					id: "plan",
					label: "পরিকল্পনা"
				}
			]
		}),
		tab === "sky" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sky, {}) : null,
		tab === "cook" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cook, {}) : null,
		tab === "plan" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plan, {}) : null
	] });
}
function Sky() {
	const [city, setCity] = (0, import_react.useState)("Dhaka");
	const [now, setNow] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	async function load(name) {
		setError("");
		try {
			const place = (await (await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(name)}&count=1&language=en`)).json()).results?.[0];
			if (!place) {
				setError("শহর পাওয়া যায়নি।");
				return;
			}
			const data = await (await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${place.latitude}&longitude=${place.longitude}&current=temperature_2m,weather_code,wind_speed_10m`)).json();
			if (!data.current) {
				setError("আকাশের খবর আসেনি।");
				return;
			}
			setNow({
				temp: data.current.temperature_2m,
				wind: data.current.wind_speed_10m,
				code: data.current.weather_code,
				city: place.name
			});
		} catch {
			setError("নেটওয়ার্ক ধরেনি।");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-md space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2",
				onSubmit: (event) => {
					event.preventDefault();
					load(city);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					value: city,
					onChange: (e) => setCity(e.target.value),
					placeholder: "শহর"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "submit",
					children: "দেখুন"
				})]
			}),
			!now && !error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				kind: "ink",
				type: "button",
				onClick: () => void load("Dhaka"),
				children: "ঢাকার আকাশ"
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-primary",
				children: error
			}) : null,
			now ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-md bg-ink p-6 text-surface",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-line",
						children: now.city
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 font-display text-6xl tabular-nums text-surface",
						children: [Math.round(now.temp), "°"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-line",
						children: [
							skyWord(now.code),
							" · বাতাস ",
							Math.round(now.wind),
							" কিমি/ঘণ্টা"
						]
					})
				]
			}) : null
		]
	});
}
function skyWord(code) {
	if (code === 0) return "পরিষ্কার";
	if (code < 3) return "মেঘলা রোদ";
	if (code < 50) return "কুয়াশা";
	if (code < 70) return "বৃষ্টি";
	if (code < 80) return "বরফ";
	return "ঝড়";
}
function Cook() {
	const [q, setQ] = (0, import_react.useState)("");
	const [people, setPeople] = (0, import_react.useState)(2);
	const [open, setOpen] = (0, import_react.useState)(recipes[0].name);
	const list = recipes.filter((recipe) => recipe.name.includes(q.trim()));
	const recipe = list.find((item) => item.name === open) ?? list[0];
	const scale = recipe ? people / recipe.base : 1;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-[16rem_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: control,
			placeholder: "খুঁজুন",
			value: q,
			onChange: (e) => setQ(e.target.value)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 space-y-2",
			children: list.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "min-h-11",
				onClick: () => setOpen(item.name),
				children: item.name
			}) }, item.name))
		})] }), recipe ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "rounded-md border border-line bg-surface p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-3xl",
					children: recipe.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: recipe.time
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-3 block text-sm text-muted",
					children: ["কতজন", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: `${control} mt-1 max-w-32`,
						type: "number",
						min: 1,
						max: 12,
						value: people,
						onChange: (e) => setPeople(Number(e.target.value) || 1)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted",
					children: [
						"মূল রেসিপি ",
						recipe.base,
						" জনের। এখন ",
						scale.toFixed(1),
						" গুণ।"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 list-disc pl-5",
					children: recipe.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item }, item))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-3 list-decimal space-y-1 pl-5",
					children: recipe.steps.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: step }, step))
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "এই নামে রান্না নেই।" })]
	});
}
function Plan() {
	const bag = useItems("plan");
	const [bucket, setBucket] = (0, import_react.useState)("পড়ালেখা");
	const [title, setTitle] = (0, import_react.useState)("");
	const [day, setDay] = (0, import_react.useState)("শনি");
	const days = [
		"শনি",
		"রবি",
		"সোম",
		"মঙ্গল",
		"বুধ",
		"বৃহ",
		"শুক্র"
	];
	const groups = (0, import_react.useMemo)(() => [
		"ভ্রমণ",
		"খাবার",
		"পড়ালেখা"
	], []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
				value: bucket,
				onChange: setBucket,
				options: groups.map((id) => ({
					id,
					label: id
				}))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-wrap gap-2",
				onSubmit: async (event) => {
					event.preventDefault();
					if (!title.trim()) return;
					await bag.add({
						bucket,
						title: title.trim(),
						day
					});
					setTitle("");
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: `${control} max-w-36`,
						value: day,
						onChange: (e) => setDay(e.target.value),
						children: days.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: d }, d))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: control,
						placeholder: "কী করবেন",
						value: title,
						onChange: (e) => setTitle(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						type: "submit",
						children: "রাখুন"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: days.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-md border border-line bg-surface p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-xl",
						children: d
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 space-y-1 text-sm",
						children: bag.items.filter((item) => item.bucket === bucket && item.day === d).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-primary",
								onClick: () => bag.remove(item.id),
								children: "×"
							})]
						}, item.id))
					})]
				}, d))
			})
		]
	});
}
//#endregion
export { Day as component };
