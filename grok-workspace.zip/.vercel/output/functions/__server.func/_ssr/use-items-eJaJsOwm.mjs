import { o as __toESM } from "../_runtime.mjs";
import { X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as updateItem, f as deleteItem, g as listItems, s as addItem } from "./ui-CrG7kmAz.mjs";
import { n as useCurrentUserState } from "./use-current-user-LXzd1evx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-items-eJaJsOwm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function storageKey(kind) {
	return `ekchala:v1:${kind}`;
}
function readLocal(kind) {
	try {
		const raw = localStorage.getItem(storageKey(kind));
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed : [];
	} catch {
		return [];
	}
}
function useItems(kind) {
	const { user, isPending } = useCurrentUserState();
	const userId = user?.id ?? null;
	const [items, setItems] = (0, import_react.useState)([]);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let cancel = false;
		if (isPending) return;
		setReady(false);
		(async () => {
			if (!userId) {
				if (!cancel) {
					setItems(readLocal(kind));
					setReady(true);
				}
				return;
			}
			try {
				const rows = await listItems({ data: kind });
				if (cancel) return;
				let next = rows.map((row) => ({
					...JSON.parse(row.payload),
					id: String(row.id)
				}));
				const mig = `ekchala:mig:${userId}:${kind}`;
				if (next.length === 0 && !localStorage.getItem(mig)) {
					const local = readLocal(kind);
					if (local.length) {
						for (const item of local) {
							const { id: _id, ...rest } = item;
							await addItem({ data: {
								kind,
								payload: JSON.stringify(rest)
							} });
						}
						localStorage.setItem(mig, "1");
						next = (await listItems({ data: kind })).map((row) => ({
							...JSON.parse(row.payload),
							id: String(row.id)
						}));
					}
				}
				if (!cancel) setItems(next);
			} catch {
				if (!cancel) setItems([]);
			} finally {
				if (!cancel) setReady(true);
			}
		})();
		return () => {
			cancel = true;
		};
	}, [
		userId,
		isPending,
		kind
	]);
	(0, import_react.useEffect)(() => {
		if (!ready || userId || isPending) return;
		localStorage.setItem(storageKey(kind), JSON.stringify(items));
	}, [
		items,
		ready,
		userId,
		isPending,
		kind
	]);
	return {
		items,
		ready,
		add: (0, import_react.useCallback)(async (payload) => {
			if (userId) {
				const row = await addItem({ data: {
					kind,
					payload: JSON.stringify(payload)
				} });
				setItems((prev) => [{
					...payload,
					id: String(row?.id ?? Date.now())
				}, ...prev]);
				return;
			}
			setItems((prev) => [{
				...payload,
				id: crypto.randomUUID()
			}, ...prev]);
		}, [userId, kind]),
		update: (0, import_react.useCallback)(async (id, payload) => {
			setItems((prev) => prev.map((item) => item.id === id ? {
				...payload,
				id
			} : item));
			const numeric = Number(id);
			if (userId && Number.isInteger(numeric) && numeric > 0) await updateItem({ data: {
				id: numeric,
				payload: JSON.stringify(payload)
			} });
		}, [userId]),
		remove: (0, import_react.useCallback)(async (id) => {
			setItems((prev) => prev.filter((item) => item.id !== id));
			const numeric = Number(id);
			if (userId && Number.isInteger(numeric) && numeric > 0) await deleteItem({ data: numeric });
		}, [userId]),
		signedIn: Boolean(userId),
		isPending
	};
}
//#endregion
export { useItems as t };
