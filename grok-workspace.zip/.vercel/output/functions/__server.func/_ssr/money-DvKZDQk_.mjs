import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as PageTitle, l as control, n as Empty, o as Tabs, r as Field, t as Btn, x as taka } from "./ui-CrG7kmAz.mjs";
import { d as sampleSales, f as sampleStock, u as sampleClass } from "./content-e_t1AhxR.mjs";
import { t as useItems } from "./use-items-eJaJsOwm.mjs";
import { a as ResponsiveContainer, i as Bar, n as YAxis, o as Tooltip, r as XAxis, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/money-DvKZDQk_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Money() {
	const [tab, setTab] = (0, import_react.useState)("spend");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
			kicker: "হিসাব",
			title: "টাকা, মাপ, আর কাগজ।"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
			value: tab,
			onChange: setTab,
			options: [
				{
					id: "spend",
					label: "খরচ"
				},
				{
					id: "dash",
					label: "ড্যাশ"
				},
				{
					id: "calc",
					label: "অঙ্ক"
				},
				{
					id: "paper",
					label: "কাগজ"
				}
			]
		}),
		tab === "spend" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spend, {}) : null,
		tab === "dash" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dash, {}) : null,
		tab === "calc" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calcs, {}) : null,
		tab === "paper" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Papers, {}) : null
	] });
}
var cats = [
	"বাজার",
	"বাড়ি",
	"বিল",
	"যাতায়াত",
	"অন্যান্য"
];
function Spend() {
	const bag = useItems("expense");
	const [title, setTitle] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)(cats[0]);
	const [amount, setAmount] = (0, import_react.useState)("");
	const grouped = (0, import_react.useMemo)(() => {
		return cats.map((name) => ({
			name,
			value: bag.items.filter((item) => item.category === name).reduce((sum, item) => sum + Number(item.amount || 0), 0)
		}));
	}, [bag.items]);
	const total = grouped.reduce((sum, row) => sum + row.value, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-[1fr_18rem]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 tabular-nums text-3xl",
				children: taka(total)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-56 w-full text-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
						data: grouped,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "name",
								stroke: "currentColor",
								fontSize: 12
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								stroke: "currentColor",
								fontSize: 12
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "value",
								fill: "var(--color-primary)",
								radius: 4
							})
						]
					})
				})
			}),
			bag.items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "খরচ যোগ করলে বার উঠবে।" }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 space-y-2",
				children: bag.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-2 border-b border-line py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [item.title, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted",
							children: [" · ", item.category]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: taka(item.amount)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 text-sm text-primary",
							onClick: () => bag.remove(item.id),
							children: "মুছুন"
						})
					]
				}, item.id))
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-3",
			onSubmit: async (event) => {
				event.preventDefault();
				const value = Number(amount);
				if (!title.trim() || !value) return;
				await bag.add({
					title: title.trim(),
					category,
					amount: value
				});
				setTitle("");
				setAmount("");
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "কী কিনলেন",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: control,
						value: title,
						onChange: (e) => setTitle(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "খাত",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: control,
						value: category,
						onChange: (e) => setCategory(e.target.value),
						children: cats.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: cat }, cat))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "টাকা",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: control,
						inputMode: "numeric",
						value: amount,
						onChange: (e) => setAmount(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "submit",
					children: "যোগ"
				})
			]
		})]
	});
}
function Chart({ title, data, note }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-md border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: note
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 h-48 text-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
						data,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "name",
								stroke: "currentColor",
								fontSize: 12
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								stroke: "currentColor",
								fontSize: 12
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "value",
								fill: "var(--color-ink)",
								radius: 4
							})
						]
					})
				})
			})
		]
	});
}
function Dash() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chart, {
				title: "বিক্রি",
				data: sampleSales,
				note: "নমুনা — দোকানের মাস।"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chart, {
				title: "স্টক",
				data: sampleStock,
				note: "নমুনা — এখন কতটা আছে।"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chart, {
				title: "ক্লাস",
				data: sampleClass,
				note: "নমুনা — ছাত্রের নম্বর।"
			})
		]
	});
}
function Calcs() {
	const [which, setWhich] = (0, import_react.useState)("emi");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
			value: which,
			onChange: setWhich,
			options: [
				{
					id: "emi",
					label: "ইএমআই"
				},
				{
					id: "bmi",
					label: "বিএমআই"
				},
				{
					id: "unit",
					label: "একক"
				},
				{
					id: "budget",
					label: "বাজেট"
				}
			]
		}),
		which === "emi" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Emi, {}) : null,
		which === "bmi" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bmi, {}) : null,
		which === "unit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Units, {}) : null,
		which === "budget" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Budget, {}) : null
	] });
}
function Emi() {
	const [p, setP] = (0, import_react.useState)("500000");
	const [rate, setRate] = (0, import_react.useState)("9");
	const [months, setMonths] = (0, import_react.useState)("60");
	const principal = Number(p) || 0;
	const n = Number(months) || 0;
	const r = (Number(rate) || 0) / 12 / 100;
	const emi = n <= 0 ? 0 : r === 0 ? principal / n : principal * r * (1 + r) ** n / ((1 + r) ** n - 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid max-w-xl gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "আসল",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					value: p,
					onChange: (e) => setP(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "বার্ষিক সুদ %",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					value: rate,
					onChange: (e) => setRate(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "মাস",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					value: months,
					onChange: (e) => setMonths(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-3xl tabular-nums",
				children: ["মাসে ", taka(emi)]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-muted",
				children: [
					"মোট ",
					taka(emi * n),
					" · সুদ ",
					taka(emi * n - principal)
				]
			})
		]
	});
}
function Bmi() {
	const [kg, setKg] = (0, import_react.useState)("64");
	const [cm, setCm] = (0, import_react.useState)("168");
	const m = (Number(cm) || 0) / 100;
	const bmi = m ? (Number(kg) || 0) / (m * m) : 0;
	const word = bmi < 18.5 ? "কম" : bmi < 25 ? "মাঝারি" : bmi < 30 ? "বেশি" : "অনেক বেশি";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid max-w-xl gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "কেজি",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					value: kg,
					onChange: (e) => setKg(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "সেন্টিমিটার",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					value: cm,
					onChange: (e) => setCm(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-3xl tabular-nums",
				children: [
					bmi.toFixed(1),
					" · ",
					word
				]
			})
		]
	});
}
function Units() {
	const [km, setKm] = (0, import_react.useState)("5");
	const [kg, setKg] = (0, import_react.useState)("1");
	const [c, setC] = (0, import_react.useState)("30");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid max-w-xl gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: "কিলোমিটার",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					value: km,
					onChange: (e) => setKm(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "tabular-nums text-muted",
					children: [((Number(km) || 0) * .621371).toFixed(2), " মাইল"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: "কিলোগ্রাম",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					value: kg,
					onChange: (e) => setKg(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "tabular-nums text-muted",
					children: [((Number(kg) || 0) * 2.20462).toFixed(2), " পাউন্ড"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: "সেলসিয়াস",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					value: c,
					onChange: (e) => setC(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "tabular-nums text-muted",
					children: [(Number(c) || 0) * 9 / 5 + 32, " ফারেনহাইট"]
				})]
			})
		]
	});
}
function Budget() {
	const [income, setIncome] = (0, import_react.useState)("40000");
	const [rent, setRent] = (0, import_react.useState)("15000");
	const [food, setFood] = (0, import_react.useState)("10000");
	const [rest, setRest] = (0, import_react.useState)("5000");
	const left = (Number(income) || 0) - (Number(rent) || 0) - (Number(food) || 0) - (Number(rest) || 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid max-w-xl gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "আয়",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					value: income,
					onChange: (e) => setIncome(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "বাড়ি",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					value: rent,
					onChange: (e) => setRent(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "বাজার",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					value: food,
					onChange: (e) => setFood(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "অন্য",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					value: rest,
					onChange: (e) => setRest(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-3xl tabular-nums",
				children: ["বাকি ", taka(left)]
			})
		]
	});
}
function Papers() {
	const [kind, setKind] = (0, import_react.useState)("ইনভয়েস");
	const [who, setWho] = (0, import_react.useState)("");
	const [line, setLine] = (0, import_react.useState)("কাজ");
	const [amount, setAmount] = (0, import_react.useState)("5000");
	const bag = useItems("paper");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-3",
			onSubmit: async (event) => {
				event.preventDefault();
				await bag.add({
					kind,
					who,
					line,
					amount: Number(amount) || 0
				});
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
					value: kind,
					onChange: setKind,
					options: [
						{
							id: "ইনভয়েস",
							label: "ইনভয়েস"
						},
						{
							id: "কোটেশন",
							label: "কোটেশন"
						},
						{
							id: "রেজুমে",
							label: "রেজুমে"
						}
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: kind === "রেজুমে" ? "নাম" : "কার জন্য",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: control,
						value: who,
						onChange: (e) => setWho(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: kind === "রেজুমে" ? "কাজের লাইন" : "বিবরণ",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: control,
						value: line,
						onChange: (e) => setLine(e.target.value)
					})
				}),
				kind === "রেজুমে" ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "টাকা",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: control,
						value: amount,
						onChange: (e) => setAmount(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						type: "submit",
						children: "রাখুন"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						kind: "ghost",
						type: "button",
						onClick: () => window.print(),
						children: "প্রিন্ট"
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "rounded-md border border-line bg-surface p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-primary",
					children: kind
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-4xl",
					children: who || "নাম"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3",
					children: line
				}),
				kind === "রেজুমে" ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-2xl tabular-nums",
					children: taka(Number(amount) || 0)
				})
			]
		})]
	});
}
//#endregion
export { Money as component };
