import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as PageTitle, n as Empty, v as listScores } from "./ui-CrG7kmAz.mjs";
import { r as SignInGate } from "./router-P86eNgIk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/board-DRk54TFz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BoardPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
		kicker: "বোর্ড",
		title: "কার কত।",
		lede: "কুইজের স্কোর আর ফোকাস ঘড়ির পঁচিশ। নাম প্রোফাইল থেকে, না থাকলে অ্যাকাউন্টের নাম।"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignInGate, {
		fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "বোর্ড দেখতে Grok-এর ভেতর থেকে খুলুন, যাতে নাম থাকে।"
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {})
	})] });
}
function List() {
	const [rows, setRows] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let cancel = false;
		listScores().then((data) => {
			if (!cancel) setRows(data);
		}).catch(() => {
			if (!cancel) setRows([]);
		});
		return () => {
			cancel = true;
		};
	}, []);
	if (!rows) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "লোড হচ্ছে…"
	});
	if (rows.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "এখনো কেউ স্কোর দেয়নি। কুইজ খেলুন।" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "max-w-xl space-y-2",
		children: rows.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-baseline justify-between gap-3 border-b border-line py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums text-muted",
					children: index + 1
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex-1",
					children: row.display_name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted",
					children: row.game
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums",
					children: row.points
				})
			]
		}, `${row.display_name}-${row.game}-${index}`))
	});
}
//#endregion
export { BoardPage as component };
