import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as listMyShares, i as PageTitle, l as control, n as Empty, p as deleteShare, r as Field, t as Btn, u as createShare } from "./ui-CrG7kmAz.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as SignInGate } from "./router-P86eNgIk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/share-BSggdyWR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SharePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
		kicker: "শেয়ার",
		title: "একটা লেখা অন্যের হাতে।",
		lede: "লিংক খুলতে ওই মানুষকেও একচালায় ঢুকতে হবে।"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignInGate, {
		fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "শেয়ার করতে Grok থেকে খোলা অ্যাকাউন্ট লাগে।"
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Composer, {})
	})] });
}
function Composer() {
	const [title, setTitle] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	const [rows, setRows] = (0, import_react.useState)([]);
	async function refresh() {
		setRows(await listMyShares());
	}
	(0, import_react.useEffect)(() => {
		let cancel = false;
		listMyShares().then((data) => {
			if (!cancel) setRows(data);
		}).catch(() => void 0);
		return () => {
			cancel = true;
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-3",
			onSubmit: async (event) => {
				event.preventDefault();
				const made = await createShare({ data: {
					title: title.trim(),
					body: body.trim()
				} });
				toast("লিংক তৈরি");
				setTitle("");
				setBody("");
				await refresh();
				if (made?.code) setRows((prev) => prev);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "শিরোনাম",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: control,
						value: title,
						onChange: (e) => setTitle(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "লেখা",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: `${control} min-h-36`,
						value: body,
						onChange: (e) => setBody(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "submit",
					disabled: !title.trim() || !body.trim(),
					children: "লিংক বানান"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "এখনো শেয়ার নেই।" }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-3",
			children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center justify-between gap-3 rounded-md border border-line bg-surface px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/s/$code",
					params: { code: row.code },
					className: "min-h-11 text-primary",
					children: row.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-11 text-sm",
					onClick: async () => {
						await deleteShare({ data: row.code });
						setRows((prev) => prev.filter((item) => item.code !== row.code));
					},
					children: "মুছুন"
				})]
			}, row.code))
		})] })]
	});
}
//#endregion
export { SharePage as component };
