import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Speak, c as addScore, i as PageTitle, l as control, n as Empty, o as Tabs, t as Btn } from "./ui-CrG7kmAz.mjs";
import { t as useCurrentUser } from "./use-current-user-LXzd1evx.mjs";
import { t as useItems } from "./use-items-eJaJsOwm.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/work-Brc-nU2o.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Work() {
	const [tab, setTab] = (0, import_react.useState)("tasks");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
			kicker: "কাজ",
			title: "যা করতে হবে, যা মনে রাখতে হবে।"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
			value: tab,
			onChange: setTab,
			options: [
				{
					id: "tasks",
					label: "তালিকা"
				},
				{
					id: "board",
					label: "বোর্ড"
				},
				{
					id: "notes",
					label: "নোট"
				},
				{
					id: "habits",
					label: "অভ্যাস"
				},
				{
					id: "focus",
					label: "ফোকাস"
				},
				{
					id: "cal",
					label: "ক্যালেন্ডার"
				},
				{
					id: "marks",
					label: "বুকমার্ক"
				},
				{
					id: "bell",
					label: "ঘণ্টা"
				}
			]
		}),
		tab === "tasks" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tasks, {}) : null,
		tab === "board" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Board, {}) : null,
		tab === "notes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notes, {}) : null,
		tab === "habits" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Habits, {}) : null,
		tab === "focus" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Focus, {}) : null,
		tab === "cal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cal, {}) : null,
		tab === "marks" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Marks, {}) : null,
		tab === "bell" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bells, {}) : null
	] });
}
function Tasks() {
	const bag = useItems("task");
	const [title, setTitle] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-xl space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2",
				onSubmit: async (event) => {
					event.preventDefault();
					if (!title.trim()) return;
					await bag.add({
						title: title.trim(),
						done: false,
						status: "todo"
					});
					setTitle("");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					value: title,
					onChange: (e) => setTitle(e.target.value),
					placeholder: "নতুন কাজ"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "submit",
					children: "যোগ"
				})]
			}),
			!bag.ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "লোড হচ্ছে…"
			}) : null,
			bag.ready && bag.items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "তালিকা খালি।" }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: bag.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-2 rounded-md border border-line bg-surface px-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 min-w-11",
							onClick: () => bag.update(item.id, {
								...item,
								done: !item.done,
								status: !item.done ? "done" : "todo"
							}),
							children: item.done ? "✓" : "○"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: item.done ? "text-muted line-through" : "",
							children: item.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "ml-auto min-h-11 text-sm text-primary",
							onClick: () => bag.remove(item.id),
							children: "মুছুন"
						})
					]
				}, item.id))
			})
		]
	});
}
var cols = [
	{
		id: "todo",
		label: "করব"
	},
	{
		id: "doing",
		label: "করছি"
	},
	{
		id: "done",
		label: "হয়ে গেছে"
	}
];
function Board() {
	const bag = useItems("task");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-3 lg:grid-cols-3",
		children: cols.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-md border border-line bg-surface p-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl",
				children: col.label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-2",
				children: bag.items.filter((item) => item.status === col.id).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-md border border-line p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: item.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex gap-2",
						children: cols.filter((next) => next.id !== item.status).map((next) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 text-sm text-primary",
							onClick: () => bag.update(item.id, {
								...item,
								status: next.id,
								done: next.id === "done"
							}),
							children: next.label
						}, next.id))
					})]
				}, item.id))
			})]
		}, col.id))
	});
}
function Notes() {
	const bag = useItems("note");
	const [title, setTitle] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(null);
	const note = bag.items.find((item) => item.id === open);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-[16rem_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-2",
			onSubmit: async (event) => {
				event.preventDefault();
				if (!title.trim()) return;
				await bag.add({
					title: title.trim(),
					body
				});
				setTitle("");
				setBody("");
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					placeholder: "শিরোনাম",
					value: title,
					onChange: (e) => setTitle(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${control} min-h-24`,
					placeholder: "লেখা",
					value: body,
					onChange: (e) => setBody(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "submit",
					children: "রাখুন"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 space-y-2",
			children: bag.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "min-h-11 text-left",
				onClick: () => setOpen(item.id),
				children: item.title
			}) }, item.id))
		})] }), note ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "rounded-md border border-line bg-surface p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-3xl",
					children: note.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 whitespace-pre-wrap",
					children: note.body
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Speak, { text: `${note.title}. ${note.body}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						kind: "ghost",
						type: "button",
						onClick: () => bag.remove(note.id),
						children: "মুছুন"
					})]
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "একটা নোট খুলুন, অথবা নতুন লিখুন।" })]
	});
}
function todayKey() {
	return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
function Habits() {
	const bag = useItems("habit");
	const [name, setName] = (0, import_react.useState)("");
	const today = todayKey();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-xl space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2",
				onSubmit: async (event) => {
					event.preventDefault();
					if (!name.trim()) return;
					await bag.add({
						name: name.trim(),
						dates: []
					});
					setName("");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					placeholder: "অভ্যাস",
					value: name,
					onChange: (e) => setName(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "submit",
					children: "যোগ"
				})]
			}),
			bag.items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "যেমন: হাঁটা, জল, পড়া।" }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: bag.items.map((item) => {
					const on = item.dates.includes(today);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 rounded-md border border-line bg-surface px-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11",
								onClick: () => bag.update(item.id, {
									name: item.name,
									dates: on ? item.dates.filter((d) => d !== today) : [...item.dates, today]
								}),
								children: on ? "আজ হয়েছে" : "আজ টিক"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.name }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "ml-auto tabular-nums text-muted",
								children: [item.dates.length, " দিন"]
							})
						]
					}, item.id);
				})
			})
		]
	});
}
function Focus() {
	const user = useCurrentUser();
	const [left, setLeft] = (0, import_react.useState)(1500);
	const [run, setRun] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!run) return;
		const timer = setInterval(() => {
			setLeft((value) => {
				if (value <= 1) {
					setRun(false);
					toast("পঁচিশ মিনিট শেষ");
					return 0;
				}
				return value - 1;
			});
		}, 1e3);
		return () => clearInterval(timer);
	}, [run]);
	const m = String(Math.floor(left / 60)).padStart(2, "0");
	const s = String(left % 60).padStart(2, "0");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-md rounded-md border border-line bg-surface p-8 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-display text-6xl tabular-nums",
				children: [
					m,
					":",
					s
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex justify-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "button",
					onClick: () => setRun((v) => !v),
					children: run ? "থামুন" : "শুরু"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					kind: "ghost",
					type: "button",
					onClick: () => {
						setRun(false);
						setLeft(1500);
					},
					children: "রিসেট"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				kind: "ink",
				className: "mt-4",
				type: "button",
				disabled: !user || left > 0,
				onClick: async () => {
					await addScore({ data: {
						displayName: user?.displayName || "অতিথি",
						game: "ফোকাস",
						points: 25
					} });
					toast("বোর্ডে উঠেছে");
					setLeft(1500);
				},
				children: "শেষ হলে বোর্ডে দিন"
			})
		]
	});
}
function Cal() {
	const bag = useItems("event");
	const [cursor, setCursor] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	const [title, setTitle] = (0, import_react.useState)("");
	const [day, setDay] = (0, import_react.useState)(todayKey());
	const year = cursor.getFullYear();
	const month = cursor.getMonth();
	const first = new Date(year, month, 1).getDay();
	const days = new Date(year, month + 1, 0).getDate();
	const label = new Intl.DateTimeFormat("bn-BD", {
		month: "long",
		year: "numeric"
	}).format(cursor);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-[1fr_16rem]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-center justify-between",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					kind: "ghost",
					type: "button",
					onClick: () => setCursor(new Date(year, month - 1, 1)),
					children: "আগে"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl",
					children: label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					kind: "ghost",
					type: "button",
					onClick: () => setCursor(new Date(year, month + 1, 1)),
					children: "পরে"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-7 gap-1 text-center text-sm",
			children: [Array.from({ length: first }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {}, `e${i}`)), Array.from({ length: days }).map((_, i) => {
				const date = `${year}-${String(month + 1).padStart(2, "0")}-${String(i + 1).padStart(2, "0")}`;
				const count = bag.items.filter((item) => item.day === date).length;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setDay(date),
					className: `min-h-11 rounded-md ${day === date ? "bg-ink text-surface" : "bg-surface"}`,
					children: [i + 1, count ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-primary",
						children: "•"
					}) : null]
				}, date);
			})]
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-2",
			onSubmit: async (event) => {
				event.preventDefault();
				if (!title.trim()) return;
				await bag.add({
					title: title.trim(),
					day
				});
				setTitle("");
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					type: "date",
					value: day,
					onChange: (e) => setDay(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					placeholder: "কী হবে",
					value: title,
					onChange: (e) => setTitle(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "submit",
					children: "দিনে রাখুন"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2 pt-2",
					children: bag.items.filter((item) => item.day === day).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-primary",
							onClick: () => bag.remove(item.id),
							children: "মুছুন"
						})]
					}, item.id))
				})
			]
		})]
	});
}
function Marks() {
	const bag = useItems("bookmark");
	const [title, setTitle] = (0, import_react.useState)("");
	const [url, setUrl] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-xl space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-2",
				onSubmit: async (event) => {
					event.preventDefault();
					if (!title.trim() || !url.trim()) return;
					const href = url.startsWith("http") ? url.trim() : `https://${url.trim()}`;
					await bag.add({
						title: title.trim(),
						url: href
					});
					setTitle("");
					setUrl("");
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: control,
						placeholder: "নাম",
						value: title,
						onChange: (e) => setTitle(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: control,
						placeholder: "লিংক",
						value: url,
						onChange: (e) => setUrl(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						type: "submit",
						children: "রাখুন"
					})
				]
			}),
			bag.items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "পড়ার লিংক এখানে।" }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: bag.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "min-h-11 text-primary",
						href: item.url,
						target: "_blank",
						rel: "noreferrer",
						children: item.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "ml-auto text-sm",
						onClick: () => bag.remove(item.id),
						children: "মুছুন"
					})]
				}, item.id))
			})
		]
	});
}
function Bells() {
	const bag = useItems("reminder");
	const [title, setTitle] = (0, import_react.useState)("");
	const [when, setWhen] = (0, import_react.useState)("");
	const [, tick] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const timer = setInterval(() => tick((n) => n + 1), 3e4);
		return () => clearInterval(timer);
	}, []);
	const due = bag.items.filter((item) => !item.acked && item.when && new Date(item.when).getTime() <= Date.now());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-xl space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "সময় হলে এই পাতায় নোটিশ আসে। ব্রাউজার বন্ধ থাকলে আসবে না — এটা ঘরের ঘড়ি, ফোনের অ্যালার্ম নয়।"
			}),
			due.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 rounded-md bg-ink px-4 py-3 text-surface",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["সময় হয়েছে: ", item.title] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-11",
					onClick: () => bag.update(item.id, {
						...item,
						acked: true
					}),
					children: "দেখেছি"
				})]
			}, item.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-2",
				onSubmit: async (event) => {
					event.preventDefault();
					if (!title.trim() || !when) return;
					await bag.add({
						title: title.trim(),
						when,
						acked: false
					});
					setTitle("");
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: control,
						placeholder: "কী মনে করাবে",
						value: title,
						onChange: (e) => setTitle(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: control,
						type: "datetime-local",
						value: when,
						onChange: (e) => setWhen(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						type: "submit",
						children: "ঘণ্টা রাখুন"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: bag.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: item.acked ? "text-muted" : "",
						children: [
							item.title,
							" · ",
							item.when.replace("T", " ")
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-primary",
						onClick: () => bag.remove(item.id),
						children: "মুছুন"
					})]
				}, item.id))
			})
		]
	});
}
//#endregion
export { Work as component };
