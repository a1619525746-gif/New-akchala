import { n as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-C_d_nkVa.mjs";
import { cn as _enum, gn as object, hn as number, yn as string } from "../_libs/@better-auth/core+[...].mjs";
import { t as createServerRpc } from "./createServerRpc-CN-evIEF.mjs";
import { r as getSql } from "./db-C7LfuUtx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/server-CX2WwBlv.js
var kindSchema = _enum([
	"task",
	"note",
	"habit",
	"bookmark",
	"event",
	"expense",
	"card",
	"poll",
	"timeline",
	"person",
	"plan",
	"reminder",
	"order",
	"wait",
	"mood",
	"paper",
	"survey"
]);
var listItems_createServerFn_handler = createServerRpc({
	id: "9ee55d01eaf28dbf7e68dde26ddd3ac1b45c4c9c12f1d35059e962cf4d51c18a",
	name: "listItems",
	filename: "src/lib/ekchala/server.ts"
}, (opts) => listItems.__executeServer(opts));
var listItems = createServerFn({ method: "GET" }).validator((kind) => kindSchema.parse(kind)).middleware([authMiddleware]).handler(listItems_createServerFn_handler, async ({ context, data: kind }) => {
	return (await getSql())`
      select id, payload from items
      where user_id = ${context.userId} and kind = ${kind}
      order by id desc
      limit 200
    `;
});
var addItem_createServerFn_handler = createServerRpc({
	id: "a29da3b379acdab98ce67a365f2862e8e10c84960fee12cfd63d3b6656522bf6",
	name: "addItem",
	filename: "src/lib/ekchala/server.ts"
}, (opts) => addItem.__executeServer(opts));
var addItem = createServerFn({ method: "POST" }).validator((input) => object({
	kind: kindSchema,
	payload: string().min(2).max(2e4)
}).parse(input)).middleware([authMiddleware]).handler(addItem_createServerFn_handler, async ({ context, data }) => {
	return (await (await getSql())`
      insert into items (user_id, kind, payload)
      values (${context.userId}, ${data.kind}, ${data.payload})
      returning id
    `)[0];
});
var updateItem_createServerFn_handler = createServerRpc({
	id: "b56a3dbcfca2d3a19441f62c5eaabe5cd65fd321a502b3d7ca80df4388581cf8",
	name: "updateItem",
	filename: "src/lib/ekchala/server.ts"
}, (opts) => updateItem.__executeServer(opts));
var updateItem = createServerFn({ method: "POST" }).validator((input) => object({
	id: number().int().positive(),
	payload: string().min(2).max(2e4)
}).parse(input)).middleware([authMiddleware]).handler(updateItem_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`
      update items set payload = ${data.payload}
      where id = ${data.id} and user_id = ${context.userId}
    `;
	return { ok: true };
});
var deleteItem_createServerFn_handler = createServerRpc({
	id: "b86cd684db867b5b0669a275304b68b4874c6c6699f66498dbba2c06e6c103f0",
	name: "deleteItem",
	filename: "src/lib/ekchala/server.ts"
}, (opts) => deleteItem.__executeServer(opts));
var deleteItem = createServerFn({ method: "POST" }).validator((id) => number().int().positive().parse(id)).middleware([authMiddleware]).handler(deleteItem_createServerFn_handler, async ({ context, data: id }) => {
	await (await getSql())`delete from items where id = ${id} and user_id = ${context.userId}`;
	return { ok: true };
});
var profileSchema = object({
	displayName: string().max(80),
	city: string().max(80),
	about: string().max(500)
});
var getProfile_createServerFn_handler = createServerRpc({
	id: "f20ee9e74897eebc1c77788b67e938f41295323bada3eecd72c55ef3e4013cce",
	name: "getProfile",
	filename: "src/lib/ekchala/server.ts"
}, (opts) => getProfile.__executeServer(opts));
var getProfile = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getProfile_createServerFn_handler, async ({ context }) => {
	const row = (await (await getSql())`
      select display_name, city, about from profiles where user_id = ${context.userId}
    `)[0];
	return {
		displayName: row?.display_name ?? "",
		city: row?.city ?? "",
		about: row?.about ?? ""
	};
});
var saveProfile_createServerFn_handler = createServerRpc({
	id: "ede6e92e372ed8700226f83f9cc958bfe0d18508f39c7b82c1d6c8093d566e70",
	name: "saveProfile",
	filename: "src/lib/ekchala/server.ts"
}, (opts) => saveProfile.__executeServer(opts));
var saveProfile = createServerFn({ method: "POST" }).validator((input) => profileSchema.parse(input)).middleware([authMiddleware]).handler(saveProfile_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`
      insert into profiles (user_id, display_name, city, about)
      values (${context.userId}, ${data.displayName}, ${data.city}, ${data.about})
      on conflict (user_id) do update
      set display_name = ${data.displayName}, city = ${data.city}, about = ${data.about}
    `;
	return { ok: true };
});
var listScores_createServerFn_handler = createServerRpc({
	id: "050c1addbb1dd7a1b8fd60adcc3783208927534778812d113afa94291fad3374",
	name: "listScores",
	filename: "src/lib/ekchala/server.ts"
}, (opts) => listScores.__executeServer(opts));
var listScores = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listScores_createServerFn_handler, async () => {
	return (await getSql())`
      select display_name, game, points, created_at::text as created_at
      from scores
      order by points desc, id desc
      limit 40
    `;
});
var addScore_createServerFn_handler = createServerRpc({
	id: "b9a606442f05f455fce82a2238eca4455857ba7120fe550da2f9b214dd08aa49",
	name: "addScore",
	filename: "src/lib/ekchala/server.ts"
}, (opts) => addScore.__executeServer(opts));
var addScore = createServerFn({ method: "POST" }).validator((input) => object({
	displayName: string().min(1).max(80),
	game: string().min(1).max(40),
	points: number().int().min(0).max(1e5)
}).parse(input)).middleware([authMiddleware]).handler(addScore_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`
      insert into scores (user_id, display_name, game, points)
      values (${context.userId}, ${data.displayName}, ${data.game}, ${data.points})
    `;
	return { ok: true };
});
var createShare_createServerFn_handler = createServerRpc({
	id: "068f7d68b778f1f268924dfd40e8800badc92eb04f2f0434ec8003e7aaf0bcd8",
	name: "createShare",
	filename: "src/lib/ekchala/server.ts"
}, (opts) => createShare.__executeServer(opts));
var createShare = createServerFn({ method: "POST" }).validator((input) => object({
	title: string().min(1).max(120),
	body: string().min(1).max(8e3)
}).parse(input)).middleware([authMiddleware]).handler(createShare_createServerFn_handler, async ({ context, data }) => {
	const { randomBytes } = await import("node:crypto");
	const sql = await getSql();
	const code = randomBytes(4).toString("hex");
	await sql`
      insert into shares (code, user_id, title, body)
      values (${code}, ${context.userId}, ${data.title}, ${data.body})
    `;
	return { code };
});
var listMyShares_createServerFn_handler = createServerRpc({
	id: "45ce22ca0b6a4eb82868e18e0fa6f5d8d6278a1afc1b69cc96fbd5b76d3cf5fb",
	name: "listMyShares",
	filename: "src/lib/ekchala/server.ts"
}, (opts) => listMyShares.__executeServer(opts));
var listMyShares = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listMyShares_createServerFn_handler, async ({ context }) => {
	return (await getSql())`
      select code, title from shares
      where user_id = ${context.userId}
      order by created_at desc
      limit 30
    `;
});
var readShare_createServerFn_handler = createServerRpc({
	id: "6356f6e8ea46d66cf03a2db8f39fb857c4353e9cc6e6960e887f7b0cbfb5cd38",
	name: "readShare",
	filename: "src/lib/ekchala/server.ts"
}, (opts) => readShare.__executeServer(opts));
var readShare = createServerFn({ method: "GET" }).validator((code) => string().regex(/^[a-f0-9]{8}$/).parse(code)).middleware([authMiddleware]).handler(readShare_createServerFn_handler, async ({ data: code }) => {
	return (await (await getSql())`
      select title, body from shares where code = ${code}
    `)[0] ?? null;
});
var deleteShare_createServerFn_handler = createServerRpc({
	id: "95834e0a92758255d9e369ee3d9640e6ecfae43a52be1be2169a9c38ccc506ef",
	name: "deleteShare",
	filename: "src/lib/ekchala/server.ts"
}, (opts) => deleteShare.__executeServer(opts));
var deleteShare = createServerFn({ method: "POST" }).validator((code) => string().regex(/^[a-f0-9]{8}$/).parse(code)).middleware([authMiddleware]).handler(deleteShare_createServerFn_handler, async ({ context, data: code }) => {
	await (await getSql())`delete from shares where code = ${code} and user_id = ${context.userId}`;
	return { ok: true };
});
function asRows(data) {
	const obj = data && typeof data === "object" ? data : null;
	return (Array.isArray(data) ? data : obj && Array.isArray(obj.items) ? obj.items : obj && Array.isArray(obj.events) ? obj.events : obj && Array.isArray(obj.files) ? obj.files : obj && Array.isArray(obj.results) ? obj.results : []).slice(0, 8).map((item) => {
		const row = item && typeof item === "object" ? item : {};
		const start = row.start && typeof row.start === "object" ? row.start : {};
		return {
			title: String(row.summary || row.name || row.title || "আইটেম"),
			meta: String(start.dateTime || start.date || row.modifiedTime || row.mimeType || "")
		};
	});
}
var fetchDesk_createServerFn_handler = createServerRpc({
	id: "f4dd86efd1f8875815044b976f262c18100652a920f700cf4285f2c8ccfc6107",
	name: "fetchDesk",
	filename: "src/lib/ekchala/server.ts"
}, (opts) => fetchDesk.__executeServer(opts));
var fetchDesk = createServerFn({ method: "POST" }).validator((input) => object({ driveQuery: string().max(80) }).parse(input)).handler(fetchDesk_createServerFn_handler, async ({ data }) => {
	const empty = (message) => ({
		ok: false,
		message,
		loginRequired: false,
		pending: false,
		rows: []
	});
	try {
		const { callTool } = await import("./client.server-FeOb4pOH.mjs");
		const { classifyCallToolError } = await import("./errors-DJ99y7xy.mjs").then((n) => n.t);
		const { ConnectorType, GoogleCalendarTools, GoogleDriveTools } = await import("./app-data-F__QmU-O.mjs").then((n) => n.t);
		const now = /* @__PURE__ */ new Date();
		const end = new Date(now.getTime() + 6048e5);
		const pack = (result) => {
			if (result.ok) return {
				ok: true,
				message: "",
				loginRequired: false,
				pending: false,
				rows: asRows(result.data)
			};
			const classified = classifyCallToolError(result);
			return {
				ok: false,
				message: classified?.message ?? "লোড হয়নি।",
				loginRequired: classified?.kind === "login",
				loginUrl: result.loginUrl,
				pending: classified?.kind === "pending",
				rows: []
			};
		};
		const [calendar, drive] = await Promise.all([callTool(GoogleCalendarTools.search, {
			timeMin: now.toISOString(),
			timeMax: end.toISOString(),
			maxResults: 8
		}, { connectorType: ConnectorType.GoogleCalendar }), callTool(GoogleDriveTools.search, { q: data.driveQuery.trim() || "type:document" }, { connectorType: ConnectorType.GoogleDrive })]);
		return {
			calendar: pack(calendar),
			drive: pack(drive)
		};
	} catch (error) {
		const message = error instanceof Error ? error.message : "ক্যালেন্ডার বা ড্রাইভ এখন পাওয়া যায়নি।";
		return {
			calendar: empty(message),
			drive: empty(message)
		};
	}
});
//#endregion
export { addItem_createServerFn_handler, addScore_createServerFn_handler, createShare_createServerFn_handler, deleteItem_createServerFn_handler, deleteShare_createServerFn_handler, fetchDesk_createServerFn_handler, getProfile_createServerFn_handler, listItems_createServerFn_handler, listMyShares_createServerFn_handler, listScores_createServerFn_handler, readShare_createServerFn_handler, saveProfile_createServerFn_handler, updateItem_createServerFn_handler };
