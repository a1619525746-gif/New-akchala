import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Speak, i as PageTitle, y as readShare } from "./ui-CrG7kmAz.mjs";
import { n as Route, r as SignInGate } from "./router-P86eNgIk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/s._code-JhSEFGTI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ShareView() {
	const { code } = Route.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignInGate, {
		fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "এই লেখা পড়তে একচালায় ঢুকতে হবে।"
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reader, { code })
	});
}
function Reader({ code }) {
	const [row, setRow] = (0, import_react.useState)(void 0);
	(0, import_react.useEffect)(() => {
		let cancel = false;
		readShare({ data: code }).then((data) => {
			if (!cancel) setRow(data);
		}).catch(() => {
			if (!cancel) setRow(null);
		});
		return () => {
			cancel = true;
		};
	}, [code]);
	if (row === void 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "লোড হচ্ছে…"
	});
	if (!row) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
		kicker: "শেয়ার",
		title: "পাওয়া যায়নি।"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
				kicker: "শেয়ার করা লেখা",
				title: row.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "whitespace-pre-wrap text-lg leading-relaxed",
				children: row.body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Speak, { text: `${row.title}. ${row.body}` })
			})
		]
	});
}
//#endregion
export { ShareView as component };
