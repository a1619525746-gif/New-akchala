import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as getServerFnById, n as createServerFn, r as TSS_SERVER_FUNCTION } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-C_d_nkVa.mjs";
import { cn as _enum, gn as object, hn as number, yn as string } from "../_libs/@better-auth/core+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-CrG7kmAz.js
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var kindSchema = _enum([
	"task",
	"note",
	"habit",
	"bookmark",
	"event",
	"expense",
	"card",
	"poll",
	"timeline",
	"person",
	"plan",
	"reminder",
	"order",
	"wait",
	"mood",
	"paper",
	"survey"
]);
var listItems = createServerFn({ method: "GET" }).validator((kind) => kindSchema.parse(kind)).middleware([authMiddleware]).handler(createSsrRpc("9ee55d01eaf28dbf7e68dde26ddd3ac1b45c4c9c12f1d35059e962cf4d51c18a"));
var addItem = createServerFn({ method: "POST" }).validator((input) => object({
	kind: kindSchema,
	payload: string().min(2).max(2e4)
}).parse(input)).middleware([authMiddleware]).handler(createSsrRpc("a29da3b379acdab98ce67a365f2862e8e10c84960fee12cfd63d3b6656522bf6"));
var updateItem = createServerFn({ method: "POST" }).validator((input) => object({
	id: number().int().positive(),
	payload: string().min(2).max(2e4)
}).parse(input)).middleware([authMiddleware]).handler(createSsrRpc("b56a3dbcfca2d3a19441f62c5eaabe5cd65fd321a502b3d7ca80df4388581cf8"));
var deleteItem = createServerFn({ method: "POST" }).validator((id) => number().int().positive().parse(id)).middleware([authMiddleware]).handler(createSsrRpc("b86cd684db867b5b0669a275304b68b4874c6c6699f66498dbba2c06e6c103f0"));
var profileSchema = object({
	displayName: string().max(80),
	city: string().max(80),
	about: string().max(500)
});
var getProfile = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("f20ee9e74897eebc1c77788b67e938f41295323bada3eecd72c55ef3e4013cce"));
var saveProfile = createServerFn({ method: "POST" }).validator((input) => profileSchema.parse(input)).middleware([authMiddleware]).handler(createSsrRpc("ede6e92e372ed8700226f83f9cc958bfe0d18508f39c7b82c1d6c8093d566e70"));
var listScores = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("050c1addbb1dd7a1b8fd60adcc3783208927534778812d113afa94291fad3374"));
var addScore = createServerFn({ method: "POST" }).validator((input) => object({
	displayName: string().min(1).max(80),
	game: string().min(1).max(40),
	points: number().int().min(0).max(1e5)
}).parse(input)).middleware([authMiddleware]).handler(createSsrRpc("b9a606442f05f455fce82a2238eca4455857ba7120fe550da2f9b214dd08aa49"));
var createShare = createServerFn({ method: "POST" }).validator((input) => object({
	title: string().min(1).max(120),
	body: string().min(1).max(8e3)
}).parse(input)).middleware([authMiddleware]).handler(createSsrRpc("068f7d68b778f1f268924dfd40e8800badc92eb04f2f0434ec8003e7aaf0bcd8"));
var listMyShares = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("45ce22ca0b6a4eb82868e18e0fa6f5d8d6278a1afc1b69cc96fbd5b76d3cf5fb"));
var readShare = createServerFn({ method: "GET" }).validator((code) => string().regex(/^[a-f0-9]{8}$/).parse(code)).middleware([authMiddleware]).handler(createSsrRpc("6356f6e8ea46d66cf03a2db8f39fb857c4353e9cc6e6960e887f7b0cbfb5cd38"));
var deleteShare = createServerFn({ method: "POST" }).validator((code) => string().regex(/^[a-f0-9]{8}$/).parse(code)).middleware([authMiddleware]).handler(createSsrRpc("95834e0a92758255d9e369ee3d9640e6ecfae43a52be1be2169a9c38ccc506ef"));
var fetchDesk = createServerFn({ method: "POST" }).validator((input) => object({ driveQuery: string().max(80) }).parse(input)).handler(createSsrRpc("f4dd86efd1f8875815044b976f262c18100652a920f700cf4285f2c8ccfc6107"));
function Btn({ kind = "solid", className = "", ...props }) {
	const look = kind === "solid" ? "bg-primary text-surface" : kind === "ink" ? "bg-ink text-surface" : "border border-line bg-surface text-ink";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		...props,
		className: `inline-flex min-h-11 items-center justify-center rounded-md px-4 text-sm font-medium disabled:opacity-50 ${look} ${className}`
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block space-y-1 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted",
			children: label
		}), children]
	});
}
var control = "min-h-11 w-full rounded-md border border-line bg-surface px-3 text-ink outline-none focus:border-ink";
function Tabs({ value, onChange, options }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "no-print -mx-1 flex gap-2 overflow-x-auto px-1 pb-3",
		children: options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => onChange(option.id),
			className: `min-h-11 shrink-0 rounded-full px-4 text-sm ${value === option.id ? "bg-ink text-surface" : "border border-line bg-surface text-ink"}`,
			children: option.label
		}, option.id))
	});
}
function Empty({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-md border border-dashed border-line px-4 py-8 text-center text-muted",
		children
	});
}
function PageTitle({ kicker, title, lede }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "mb-6 max-w-3xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-primary",
				children: kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 text-4xl leading-tight sm:text-5xl",
				children: title
			}),
			lede ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-lg text-muted",
				children: lede
			}) : null
		]
	});
}
function Speak({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
		kind: "ghost",
		type: "button",
		onClick: () => {
			if (typeof speechSynthesis === "undefined") return;
			const utter = new SpeechSynthesisUtterance(text);
			utter.lang = "bn-BD";
			speechSynthesis.cancel();
			speechSynthesis.speak(utter);
		},
		children: "শোনাও"
	});
}
function taka(n) {
	return `৳${new Intl.NumberFormat("bn-BD").format(Math.round(n))}`;
}
//#endregion
export { updateItem as S, listMyShares as _, Speak as a, saveProfile as b, addScore as c, createSsrRpc as d, deleteItem as f, listItems as g, getProfile as h, PageTitle as i, control as l, fetchDesk as m, Empty as n, Tabs as o, deleteShare as p, Field as r, addItem as s, Btn as t, createShare as u, listScores as v, taka as x, readShare as y };
