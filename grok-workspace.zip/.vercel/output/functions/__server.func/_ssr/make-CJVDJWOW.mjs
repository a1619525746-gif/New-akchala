import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as addScore, i as PageTitle, l as control, n as Empty, o as Tabs, t as Btn } from "./ui-CrG7kmAz.mjs";
import { t as useCurrentUser } from "./use-current-user-LXzd1evx.mjs";
import { a as names, c as quiz, m as surveyQuestions, p as starterCards } from "./content-e_t1AhxR.mjs";
import { t as useItems } from "./use-items-eJaJsOwm.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/make-CJVDJWOW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Make() {
	const [tab, setTab] = (0, import_react.useState)("draw");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
			kicker: "বানানো",
			title: "হাতের কাজ ও খেলা।"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
			value: tab,
			onChange: setTab,
			options: [
				{
					id: "draw",
					label: "আঁকা"
				},
				{
					id: "mood",
					label: "মুড"
				},
				{
					id: "quiz",
					label: "কুইজ"
				},
				{
					id: "cards",
					label: "কার্ড"
				},
				{
					id: "poll",
					label: "ভোট"
				},
				{
					id: "survey",
					label: "জরিপ"
				},
				{
					id: "time",
					label: "কালপঞ্জি"
				},
				{
					id: "tree",
					label: "বংশ"
				},
				{
					id: "gen",
					label: "জেনারেটর"
				}
			]
		}),
		tab === "draw" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Draw, {}) : null,
		tab === "mood" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mood, {}) : null,
		tab === "quiz" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quiz, {}) : null,
		tab === "cards" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cards, {}) : null,
		tab === "poll" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Poll, {}) : null,
		tab === "survey" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Survey, {}) : null,
		tab === "time" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timeline, {}) : null,
		tab === "tree" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tree, {}) : null,
		tab === "gen" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gens, {}) : null
	] });
}
function Draw() {
	const ref = (0, import_react.useRef)(null);
	const drawing = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas) return;
		const resize = () => {
			const rect = canvas.getBoundingClientRect();
			const ratio = window.devicePixelRatio || 1;
			canvas.width = rect.width * ratio;
			canvas.height = rect.height * ratio;
			const ctx = canvas.getContext("2d");
			if (!ctx) return;
			ctx.scale(ratio, ratio);
			ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue("--color-surface");
			ctx.fillRect(0, 0, rect.width, rect.height);
		};
		resize();
	}, []);
	function pos(event) {
		const rect = event.currentTarget.getBoundingClientRect();
		return {
			x: event.clientX - rect.left,
			y: event.clientY - rect.top
		};
	}
	function stroke(event) {
		if (!drawing.current) return;
		const ctx = ref.current?.getContext("2d");
		if (!ctx) return;
		const { x, y } = pos(event);
		ctx.lineTo(x, y);
		ctx.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue("--color-primary");
		ctx.lineWidth = 3;
		ctx.lineCap = "round";
		ctx.stroke();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref,
		className: "h-80 w-full touch-none rounded-md border border-line bg-surface",
		onPointerDown: (event) => {
			drawing.current = true;
			const ctx = ref.current?.getContext("2d");
			const { x, y } = pos(event);
			ctx?.beginPath();
			ctx?.moveTo(x, y);
			event.currentTarget.setPointerCapture(event.pointerId);
		},
		onPointerMove: stroke,
		onPointerUp: () => {
			drawing.current = false;
		}
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
		kind: "ghost",
		className: "mt-3",
		type: "button",
		onClick: () => {
			const canvas = ref.current;
			const ctx = canvas?.getContext("2d");
			if (!canvas || !ctx) return;
			ctx.setTransform(1, 0, 0, 1, 0, 0);
			ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue("--color-surface");
			ctx.fillRect(0, 0, canvas.width, canvas.height);
		},
		children: "মুছে ফেলুন"
	})] });
}
var swatches = [
	"bg-primary",
	"bg-ink",
	"bg-line",
	"bg-muted"
];
function Mood() {
	const bag = useItems("mood");
	const [word, setWord] = (0, import_react.useState)("");
	const [tone, setTone] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-xl space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2",
				onSubmit: async (event) => {
					event.preventDefault();
					if (!word.trim()) return;
					await bag.add({
						word: word.trim(),
						tone
					});
					setWord("");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					placeholder: "একটা শব্দ",
					value: word,
					onChange: (e) => setWord(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "submit",
					children: "পিন"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2",
				children: swatches.map((cls, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "রং",
					onClick: () => setTone(index),
					className: `h-11 w-11 rounded-full ${cls} ${tone === index ? "ring-2 ring-ink ring-offset-2" : ""}`
				}, cls))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-3",
				children: bag.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => bag.remove(item.id),
					className: `min-h-28 rounded-md p-4 text-left text-surface ${swatches[item.tone] ?? swatches[0]}`,
					children: item.word
				}, item.id))
			})
		]
	});
}
function Quiz() {
	const user = useCurrentUser();
	const [step, setStep] = (0, import_react.useState)(0);
	const [score, setScore] = (0, import_react.useState)(0);
	const [done, setDone] = (0, import_react.useState)(false);
	const card = quiz[step];
	if (done) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-md space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-4xl tabular-nums",
				children: [
					score,
					" / ",
					quiz.length
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				type: "button",
				disabled: !user,
				onClick: async () => {
					await addScore({ data: {
						displayName: user?.displayName || "নামহীন",
						game: "কুইজ",
						points: score
					} });
					toast("বোর্ডে উঠেছে");
				},
				children: "বোর্ডে দিন"
			}),
			!user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "বোর্ডে দিতে অ্যাকাউন্ট লাগে।"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				kind: "ghost",
				type: "button",
				onClick: () => {
					setStep(0);
					setScore(0);
					setDone(false);
				},
				children: "আবার"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					step + 1,
					" / ",
					quiz.length
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 text-3xl",
				children: card.q
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid gap-2",
				children: card.options.map((option, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-11 rounded-md border border-line bg-surface px-4 text-left",
					onClick: () => {
						const next = score + (index === card.a ? 1 : 0);
						if (step + 1 >= quiz.length) {
							setScore(next);
							setDone(true);
						} else {
							setScore(next);
							setStep(step + 1);
						}
					},
					children: option
				}, option))
			})
		]
	});
}
function Cards() {
	const bag = useItems("card");
	const [front, setFront] = (0, import_react.useState)("");
	const [back, setBack] = (0, import_react.useState)("");
	const [i, setI] = (0, import_react.useState)(0);
	const [flip, setFlip] = (0, import_react.useState)(false);
	const deck = bag.items.length ? bag.items : starterCards.map((card, index) => ({
		...card,
		id: `s${index}`
	}));
	const card = deck[i % deck.length];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-md space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setFlip((v) => !v),
				className: "flex min-h-48 w-full items-center justify-center rounded-md border border-line bg-surface p-6 text-center text-3xl",
				children: flip ? card.back : card.front
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					kind: "ghost",
					type: "button",
					onClick: () => {
						setFlip(false);
						setI((n) => (n + 1) % deck.length);
					},
					children: "পরেরটা"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-2",
				onSubmit: async (event) => {
					event.preventDefault();
					if (!front.trim() || !back.trim()) return;
					await bag.add({
						front: front.trim(),
						back: back.trim()
					});
					setFront("");
					setBack("");
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: control,
						placeholder: "সামনে",
						value: front,
						onChange: (e) => setFront(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: control,
						placeholder: "পেছনে",
						value: back,
						onChange: (e) => setBack(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						type: "submit",
						children: "নিজের কার্ড"
					})
				]
			})
		]
	});
}
function Poll() {
	const bag = useItems("poll");
	const [question, setQuestion] = (0, import_react.useState)("");
	const [opts, setOpts] = (0, import_react.useState)("হ্যাঁ, না");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-2",
				onSubmit: async (event) => {
					event.preventDefault();
					const options = opts.split(",").map((part) => part.trim()).filter(Boolean).map((label) => ({
						label,
						votes: 0
					}));
					if (!question.trim() || options.length < 2) return;
					await bag.add({
						question: question.trim(),
						options
					});
					setQuestion("");
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: control,
						placeholder: "প্রশ্ন",
						value: question,
						onChange: (e) => setQuestion(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: control,
						placeholder: "অপশন, কমা দিয়ে",
						value: opts,
						onChange: (e) => setOpts(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						type: "submit",
						children: "ভোট খুলুন"
					})
				]
			}),
			bag.items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "একটা প্রশ্ন খুলুন।" }) : null,
			bag.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-md border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-2xl",
					children: item.question
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 space-y-2",
					children: item.options.map((option, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex min-h-11 w-full items-center justify-between rounded-md border border-line px-3",
						onClick: () => {
							const options = item.options.map((opt, i) => i === index ? {
								...opt,
								votes: opt.votes + 1
							} : opt);
							bag.update(item.id, {
								question: item.question,
								options
							});
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: option.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: option.votes
						})]
					}, option.label))
				})]
			}, item.id))
		]
	});
}
function Survey() {
	const bag = useItems("survey");
	const [answers, setAnswers] = (0, import_react.useState)(() => surveyQuestions.map(() => ""));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "max-w-xl space-y-3",
		onSubmit: async (event) => {
			event.preventDefault();
			await bag.add({ answers });
			toast("জরিপ জমা");
			setAnswers(surveyQuestions.map(() => ""));
		},
		children: [
			surveyQuestions.map((question, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: question }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					value: answers[index],
					onChange: (e) => setAnswers((prev) => prev.map((value, i) => i === index ? e.target.value : value))
				})]
			}, question)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				type: "submit",
				children: "জমা"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [bag.items.length, "টা উত্তর রাখা আছে।"]
			})
		]
	});
}
function Timeline() {
	const bag = useItems("timeline");
	const [year, setYear] = (0, import_react.useState)("২০২০");
	const [title, setTitle] = (0, import_react.useState)("");
	const [text, setText] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-xl space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-2",
			onSubmit: async (event) => {
				event.preventDefault();
				if (!title.trim()) return;
				await bag.add({
					year,
					title: title.trim(),
					text
				});
				setTitle("");
				setText("");
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					value: year,
					onChange: (e) => setYear(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					placeholder: "কী হয়েছিল",
					value: title,
					onChange: (e) => setTitle(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					placeholder: "এক লাইন",
					value: text,
					onChange: (e) => setText(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "submit",
					children: "বসান"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "space-y-4 border-l border-line pl-4",
			children: bag.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-primary",
					children: item.year
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-2xl",
					children: item.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: item.text
				})
			] }, item.id))
		})]
	});
}
function Tree() {
	const bag = useItems("person");
	const [name, setName] = (0, import_react.useState)("");
	const [parent, setParent] = (0, import_react.useState)("");
	const roots = bag.items.filter((item) => !item.parent);
	function kids(id) {
		return bag.items.filter((item) => item.parent === id);
	}
	function Branch({ id, name: label }) {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "mt-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), kids(id).length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "ml-4 border-l border-line pl-3",
				children: kids(id).map((child) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Branch, {
					id: child.id,
					name: child.name
				}, child.id))
			}) : null]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-xl space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-2",
				onSubmit: async (event) => {
					event.preventDefault();
					if (!name.trim()) return;
					await bag.add({
						name: name.trim(),
						parent
					});
					setName("");
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: control,
						placeholder: "নাম",
						value: name,
						onChange: (e) => setName(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: control,
						value: parent,
						onChange: (e) => setParent(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "কারও সন্তান নয়"
						}), bag.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item.id,
							children: item.name
						}, item.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						type: "submit",
						children: "যোগ"
					})
				]
			}),
			roots.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "প্রথম নামটা মূল।" }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: roots.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Branch, {
				id: item.id,
				name: item.name
			}, item.id)) })
		]
	});
}
function Gens() {
	const [which, setWhich] = (0, import_react.useState)("name");
	const [batch, setBatch] = (0, import_react.useState)(names.soft.slice(0, 3));
	const [password, setPassword] = (0, import_react.useState)("");
	const [colors, setColors] = (0, import_react.useState)([
		"#c4512c",
		"#1a1612",
		"#f3eee6",
		"#6f675c",
		"#e0d5c6"
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
				value: which,
				onChange: setWhich,
				options: [
					{
						id: "name",
						label: "নাম"
					},
					{
						id: "pass",
						label: "পাসওয়ার্ড"
					},
					{
						id: "color",
						label: "রং"
					}
				]
			}),
			which === "name" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "button",
					onClick: () => setBatch(pick(names.soft)),
					children: "নরম"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					kind: "ink",
					type: "button",
					onClick: () => setBatch(pick(names.sharp)),
					children: "তীক্ষ্ণ"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 space-y-2 text-2xl",
				children: batch.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: name }, name))
			})] }) : null,
			which === "pass" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						type: "button",
						onClick: () => {
							const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
							const bytes = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(14));
							setPassword(Array.from(bytes, (b) => alphabet[b % 57]).join(""));
						},
						children: "বানান"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "break-all font-mono text-xl",
						children: password || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						kind: "ghost",
						type: "button",
						onClick: () => navigator.clipboard.writeText(password).then(() => toast("কপি")),
						children: "কপি"
					})
				]
			}) : null,
			which === "color" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				type: "button",
				onClick: () => {
					const hue = Math.floor(Math.random() * 360);
					setColors([
						0,
						24,
						48,
						200,
						40
					].map((shift, index) => {
						return hsl((hue + shift) % 360, 38, index === 2 ? 92 : index === 4 ? 80 : 42);
					}));
				},
				children: "নতুন পাতা"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid grid-cols-5 gap-2",
				children: colors.map((color) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-24 rounded-md",
					style: { background: color },
					onClick: () => navigator.clipboard.writeText(color).then(() => toast(color))
				}, color))
			})] }) : null
		]
	});
}
function pick(list) {
	return [...list].sort(() => Math.random() - .5).slice(0, 3);
}
function hsl(h, s, l) {
	const a = s / 100 * Math.min(l / 100, 1 - l / 100);
	const f = (n) => {
		const k = (n + h / 30) % 12;
		const c = l / 100 - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
		return Math.round(255 * c).toString(16).padStart(2, "0");
	};
	return `#${f(0)}${f(8)}${f(4)}`;
}
//#endregion
export { Make as component };
