import { C as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useCurrentUserState } from "./use-current-user-LXzd1evx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-DXfBbTPi.js
var import_jsx_runtime = require_jsx_runtime();
function Login() {
	const { user, isPending } = useCurrentUserState();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center bg-bg px-6 text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-primary",
					children: "একচালা"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-4xl",
					children: "অ্যাকাউন্ট"
				}),
				isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-16 animate-pulse rounded-md bg-line" }) : null,
				!isPending && user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-lg",
					children: [
						"আপনি ঢুকে আছেন",
						user.displayName ? `, ${user.displayName}` : "",
						"। প্রোফাইল, হিসাব আর শেয়ার এই নামেই জমা হয়।"
					]
				}) : null,
				!isPending && !user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-lg text-muted",
					children: "Grok-এর ভেতর থেকে খুললে অ্যাকাউন্ট নিজে থেকেই খোলে — আলাদা বাটন লাগে না। না খুললে এই ব্রাউজারেই সব কাজ সেভ থাকে, পরে অ্যাকাউন্ট ধরলে সেগুলো উঠে আসে।"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "inline-flex min-h-11 items-center text-primary",
					children: "ঘরে ফিরুন"
				})
			]
		})
	});
}
//#endregion
export { Login as component };
