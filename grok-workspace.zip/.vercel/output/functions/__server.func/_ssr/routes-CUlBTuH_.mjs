import { C as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CUlBTuH_.js
var import_jsx_runtime = require_jsx_runtime();
var rooms = [
	{
		to: "/sites",
		kicker: "সাইট",
		title: "দোকান থেকে নিমন্ত্রণ",
		text: "দশ রকম ব্যবসা, পোর্টফোলিও, পত্রিকা, দোকান, আর এক পাতার আমন্ত্রণ।"
	},
	{
		to: "/work",
		kicker: "কাজ",
		title: "তালিকা, নোট, ঘড়ি",
		text: "কানবান, অভ্যাস, পোমোডোরো, ক্যালেন্ডার, বুকমার্ক, রিমাইন্ডার।"
	},
	{
		to: "/money",
		kicker: "হিসাব",
		title: "টাকা ও কাগজ",
		text: "খরচের চার্ট, ইএমআই, বিএমআই, একক, ইনভয়েস, কোটেশন, রেজুমে।"
	},
	{
		to: "/make",
		kicker: "বানানো",
		title: "আঁকা, কুইজ, ভোট",
		text: "ক্যানভাস, মুড, ফ্ল্যাশকার্ড, জরিপ, কালপঞ্জি, বংশতালিকা, নাম ও রং।"
	},
	{
		to: "/day",
		kicker: "দিন",
		title: "আবহাওয়া, রান্না, পথ",
		text: "আজকের আকাশ, রেসিপি, আর সপ্তাহের খাবার-পড়ার পরিকল্পনা।"
	},
	{
		to: "/desk",
		kicker: "ডেস্ক",
		title: "ক্যালেন্ডার ও ড্রাইভ",
		text: "Grok-এ জোড়া থাকলে সামনের সাত দিন আর ফাইলের খোঁজ।"
	}
];
function Home() {
	const today = new Intl.DateTimeFormat("bn-BD", { dateStyle: "full" }).format(/* @__PURE__ */ new Date());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "border-b border-line pb-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: today
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 max-w-3xl text-5xl leading-none sm:text-7xl",
						children: "সব ঘর এক ছাদে।"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-2xl text-lg text-muted",
						children: "ব্যবসার পাতা, নিজের খাতা, হিসাব, কুইজ, আর শেয়ার — আলাদা সাইট নয়। একচালা একটাই জায়গা। অ্যাকাউন্ট খোলা থাকলে ডেটা ডিভাইস পেরোয়।"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-px overflow-hidden rounded-md border border-line bg-line sm:grid-cols-2 lg:grid-cols-3",
				children: rooms.map((room) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: room.to,
					className: "flex min-h-44 flex-col bg-surface p-5 hover:bg-bg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-primary",
							children: room.kicker
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-3 font-display text-3xl",
							children: room.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-2 text-muted",
							children: room.text
						})
					]
				}, room.to))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-6 border-t border-line pt-6 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/board",
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl",
							children: "বোর্ড"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-muted",
							children: "কুইজ আর ফোকাস ঘড়ির স্কোর। নাম সহ।"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/share",
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl",
							children: "শেয়ার"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-muted",
							children: "একটা লেখা অন্য লগ-ইন করা মানুষকে পাঠান।"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/me",
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl",
							children: "আমি"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-muted",
							children: "প্রোফাইল। এই নামেই বোর্ডে উঠবেন।"
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { Home as component };
