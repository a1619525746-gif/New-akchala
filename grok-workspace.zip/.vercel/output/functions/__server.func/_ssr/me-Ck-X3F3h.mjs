import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as saveProfile, h as getProfile, i as PageTitle, l as control, r as Field, t as Btn } from "./ui-CrG7kmAz.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as SignInGate } from "./router-P86eNgIk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/me-Ck-X3F3h.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Me() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
		kicker: "আমি",
		title: "যে নামে আপনাকে চেনা যাবে।",
		lede: "বোর্ড আর শেয়ার এই নাম ব্যবহার করে। Grok থেকে খুললে অ্যাকাউন্ট নিজেই থাকে।"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignInGate, {
		fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "max-w-md text-muted",
			children: "এই ব্রাউজারে আপনি অতিথি। Grok-এর ভেতর থেকে খুললে প্রোফাইল খোলে।"
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileForm, {})
	})] });
}
function ProfileForm() {
	const [displayName, setDisplayName] = (0, import_react.useState)("");
	const [city, setCity] = (0, import_react.useState)("");
	const [about, setAbout] = (0, import_react.useState)("");
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let cancel = false;
		getProfile().then((profile) => {
			if (cancel) return;
			setDisplayName(profile.displayName);
			setCity(profile.city);
			setAbout(profile.about);
		}).catch(() => void 0).finally(() => {
			if (!cancel) setReady(true);
		});
		return () => {
			cancel = true;
		};
	}, []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "লোড হচ্ছে…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "max-w-md space-y-3",
		onSubmit: async (event) => {
			event.preventDefault();
			await saveProfile({ data: {
				displayName,
				city,
				about
			} });
			toast("প্রোফাইল রাখা হয়েছে");
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "নাম",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					value: displayName,
					onChange: (e) => setDisplayName(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "শহর",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: control,
					value: city,
					onChange: (e) => setCity(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "নিজের কথা",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${control} min-h-28`,
					value: about,
					onChange: (e) => setAbout(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				type: "submit",
				children: "রাখুন"
			})
		]
	});
}
//#endregion
export { Me as component };
