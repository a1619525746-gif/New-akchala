import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Speak, i as PageTitle, l as control, n as Empty, o as Tabs, t as Btn, x as taka } from "./ui-CrG7kmAz.mjs";
import { i as docs, n as businesses, o as portfolio, r as course, s as products, t as articles } from "./content-e_t1AhxR.mjs";
import { t as useItems } from "./use-items-eJaJsOwm.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sites-D0SVUMNL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Sites() {
	const [mode, setMode] = (0, import_react.useState)("biz");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
			kicker: "সাইট স্টুডিও",
			title: "যে পাতা খুললেই সাইট।",
			lede: "একই ঘরে ব্যবসা, কাজের খাতা, লেখা, দোকান, আর নিমন্ত্রণ।"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
			value: mode,
			onChange: (id) => setMode(id),
			options: [
				{
					id: "biz",
					label: "ব্যবসা"
				},
				{
					id: "folio",
					label: "পোর্টফোলিও"
				},
				{
					id: "press",
					label: "পত্রিকা"
				},
				{
					id: "shop",
					label: "দোকান"
				},
				{
					id: "promo",
					label: "নিমন্ত্রণ"
				}
			]
		}),
		mode === "biz" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Biz, {}) : null,
		mode === "folio" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Folio, {}) : null,
		mode === "press" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Press, {}) : null,
		mode === "shop" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shop, {}) : null,
		mode === "promo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Promo, {}) : null
	] });
}
function Biz() {
	const [id, setId] = (0, import_react.useState)(businesses[0].id);
	const biz = businesses.find((item) => item.id === id) ?? businesses[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
			value: id,
			onChange: setId,
			options: businesses.map((item) => ({
				id: item.id,
				label: item.kind
			}))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "overflow-hidden rounded-md border border-line bg-surface",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-ink px-6 py-10 text-surface",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-line",
						children: [
							biz.kind,
							" · ",
							biz.place
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 text-5xl text-surface",
						children: biz.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-lg text-line",
						children: biz.line
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-8 px-6 py-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-2xl text-lg",
						children: biz.about
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-px overflow-hidden rounded-md border border-line bg-line sm:grid-cols-3",
						children: biz.services.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-surface p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: service.detail
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-2 text-2xl",
									children: service.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 tabular-nums text-primary",
									children: service.price
								})
							]
						}, service.name))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: biz.reviews.map((review) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
							className: "border-l-2 border-primary pl-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: review.text }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
								className: "mt-2 text-sm text-muted",
								children: review.name
							})]
						}, review.name))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2",
						children: biz.faqs.map((faq) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
							className: "rounded-md border border-line px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
								className: "min-h-11 cursor-pointer",
								children: faq.q
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "pb-2 text-muted",
								children: faq.a
							})]
						}, faq.q))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-3 border-t border-line pt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted",
							children: biz.address
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "inline-flex min-h-11 items-center text-primary",
							href: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(biz.map)}`,
							target: "_blank",
							rel: "noreferrer",
							children: "ম্যাপে দেখুন"
						})]
					})
				]
			})]
		})]
	});
}
function Folio() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-primary",
					children: portfolio.role
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-5xl",
					children: portfolio.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-2xl text-lg text-muted",
					children: portfolio.about
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "space-y-6",
				children: portfolio.projects.map((project, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid gap-3 border-t border-line pt-6 sm:grid-cols-[8rem_1fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-4xl tabular-nums text-primary",
						children: ["০", index + 1]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								project.kind,
								" · ",
								project.year
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-3xl",
							children: project.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-xl",
							children: project.text
						})
					] })]
				}, project.title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-muted",
				children: ["যোগাযোগ: ", portfolio.contact]
			})
		]
	});
}
function Press() {
	const [tab, setTab] = (0, import_react.useState)("write");
	const [open, setOpen] = (0, import_react.useState)(articles[0].id);
	const piece = articles.find((item) => item.id === open) ?? articles[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
			value: tab,
			onChange: setTab,
			options: [
				{
					id: "write",
					label: "লেখা"
				},
				{
					id: "course",
					label: "কোর্স"
				},
				{
					id: "docs",
					label: "ডক"
				}
			]
		}),
		tab === "write" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 lg:grid-cols-[16rem_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: articles.map((article) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setOpen(article.id),
					className: `block min-h-11 w-full rounded-md px-3 text-left ${open === article.id ? "bg-ink text-surface" : "bg-surface"}`,
					children: article.title
				}, article.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-md border border-line bg-surface p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-primary",
						children: piece.kicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 text-4xl",
						children: piece.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-lg leading-relaxed",
						children: piece.body
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Speak, { text: `${piece.title}. ${piece.body}` })
					})
				]
			})]
		}) : null,
		tab === "course" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "space-y-3",
			children: course.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-md border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-2xl",
					children: step.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: step.detail
				})]
			}, step.name))
		}) : null,
		tab === "docs" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-3",
			children: docs.map((doc) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-md border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-2xl",
					children: doc.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: doc.detail
				})]
			}, doc.name))
		}) : null
	] });
}
function Shop() {
	const [tag, setTag] = (0, import_react.useState)("সব");
	const [cart, setCart] = (0, import_react.useState)([]);
	const [open, setOpen] = (0, import_react.useState)(null);
	const [note, setNote] = (0, import_react.useState)("");
	const orders = useItems("order");
	const tags = ["সব", ...new Set(products.map((item) => item.tag))];
	const shown = products.filter((item) => tag === "সব" || item.tag === tag);
	const product = products.find((item) => item.id === open);
	const total = cart.reduce((sum, line) => {
		const item = products.find((p) => p.id === line.id);
		return sum + (item ? item.price * line.qty : 0);
	}, 0);
	const slip = (0, import_react.useMemo)(() => cart.map((line) => {
		const item = products.find((p) => p.id === line.id);
		return item ? `${item.name} × ${line.qty}` : "";
	}).filter(Boolean).join(", "), [cart]);
	function add(id) {
		setCart((prev) => {
			if (prev.find((line) => line.id === id)) return prev.map((line) => line.id === id ? {
				...line,
				qty: line.qty + 1
			} : line);
			return [...prev, {
				id,
				qty: 1
			}];
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-[1fr_18rem]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
				value: tag,
				onChange: setTag,
				options: tags.map((item) => ({
					id: item,
					label: item
				}))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: shown.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setOpen(item.id),
					className: "rounded-md border border-line bg-surface p-4 text-left",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: item.tag
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-2xl",
							children: item.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 tabular-nums",
							children: taka(item.price)
						})
					]
				}, item.id))
			}),
			product ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-md border border-ink bg-surface p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-3xl",
						children: product.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted",
						children: product.detail
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 tabular-nums text-primary",
						children: taka(product.price)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						className: "mt-4",
						type: "button",
						onClick: () => add(product.id),
						children: "ব্যাগে রাখুন"
					})
				]
			}) : null
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "h-fit rounded-md border border-line bg-surface p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-2xl",
					children: "ব্যাগ"
				}),
				cart.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted",
					children: "এখনো খালি।"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: cart.map((line) => {
						const item = products.find((p) => p.id === line.id);
						if (!item) return null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								item.name,
								" × ",
								line.qty
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 text-primary",
								onClick: () => setCart((prev) => prev.filter((x) => x.id !== line.id)),
								children: "বাদ"
							})]
						}, line.id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 tabular-nums",
					children: ["মোট ", taka(total)]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${control} mt-3 min-h-24`,
					placeholder: "ঠিকানা বা নোট",
					value: note,
					onChange: (e) => setNote(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					className: "mt-3 w-full",
					type: "button",
					disabled: !slip,
					onClick: async () => {
						await orders.add({
							lines: slip,
							note
						});
						const text = `অর্ডার: ${slip}. নোট: ${note}. মোট ${taka(total)}`;
						await navigator.clipboard.writeText(text).catch(() => void 0);
						toast("অর্ডার জমা হয়েছে, লেখা কপি হয়েছে");
						setCart([]);
						setNote("");
					},
					children: "অর্ডার রাখুন"
				})
			]
		})]
	});
}
function Promo() {
	const target = (/* @__PURE__ */ new Date("2026-12-12T18:00:00+06:00")).getTime();
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	const [name, setName] = (0, import_react.useState)("");
	const waits = useItems("wait");
	(0, import_react.useEffect)(() => {
		const timer = setInterval(() => setNow(Date.now()), 1e3);
		return () => clearInterval(timer);
	}, []);
	const left = Math.max(0, target - now);
	const days = Math.floor(left / 864e5);
	const hours = Math.floor(left % 864e5 / 36e5);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-md bg-ink px-6 py-12 text-surface",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-line",
				children: "১২ ডিসেম্বর · সন্ধ্যা ছয়টা · পুরান ঢাকা"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 text-5xl text-surface sm:text-6xl",
				children: "অন্বেষা ও রুদ্র"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-xl text-lg text-line",
				children: "বিয়ের সন্ধ্যা। গান একটা, খাবার বসার পর। নাম রাখলে জায়গা রাখা হবে।"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-8 font-display text-4xl tabular-nums text-surface",
				children: [
					days,
					" দিন ",
					hours,
					" ঘণ্টা"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-8 flex max-w-md flex-col gap-3 sm:flex-row",
				onSubmit: async (event) => {
					event.preventDefault();
					if (!name.trim()) return;
					await waits.add({ name: name.trim() });
					toast("নাম রাখা হয়েছে");
					setName("");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: `${control} text-ink`,
					placeholder: "আপনার নাম",
					value: name,
					onChange: (e) => setName(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "submit",
					children: "আসব"
				})]
			}),
			waits.items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "এখনো কেউ নাম রাখেনি।" }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 space-y-1 text-line",
				children: waits.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item.name }, item.id))
			})
		]
	});
}
//#endregion
export { Sites as component };
