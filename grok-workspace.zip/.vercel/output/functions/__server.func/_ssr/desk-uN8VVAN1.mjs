import { o as __toESM } from "../_runtime.mjs";
import { n as CONNECTOR_TOKEN_READY_EVENT } from "./types-D3FEuKtl.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as createServerFn } from "./ssr.mjs";
import { d as createSsrRpc, i as PageTitle, l as control, m as fetchDesk, t as Btn } from "./ui-CrG7kmAz.mjs";
import { i as redirectToLoginIfRequired, n as isFramed } from "./errors-DJ99y7xy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/desk-uN8VVAN1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var getConnectorReadiness = createServerFn({ method: "POST" }).handler(createSsrRpc("ac303419f3bd6f94ee837f95e91005a600278deed4876cb96a25aa0d69185951"));
var READINESS_PROBE_DELAYS_MS = [
	1e3,
	2e3,
	3e3,
	5e3
];
var READINESS_PROBE_MAX_TOTAL_MS = 18e4;
function readinessProbeDelayMs(attempt) {
	return READINESS_PROBE_DELAYS_MS[Math.min(Math.max(attempt, 0), READINESS_PROBE_DELAYS_MS.length - 1)];
}
function readinessProbeExhausted(startedAtMs, nowMs) {
	return nowMs - startedAtMs >= READINESS_PROBE_MAX_TOTAL_MS;
}
var READINESS_PROBE_TIMEOUT_MS = 1e4;
function withTimeout(promise, ms) {
	return new Promise((resolve) => {
		const timer = setTimeout(() => resolve(null), ms);
		const settle = (value) => {
			clearTimeout(timer);
			resolve(value);
		};
		promise.then(settle, () => settle(null));
	});
}
async function isConnectorReady() {
	return (await withTimeout(getConnectorReadiness(), READINESS_PROBE_TIMEOUT_MS))?.ready === true;
}
/**
* While `waiting` is true (a connector call returned `pending`), probes the
* server for the connector token and calls `refetch` once it is present. The
* probe is a header check on the app's own server — it never reaches the gate.
* A `connector-token-ready` bridge event from the Grok preview chrome triggers
* `refetch` immediately. A top-level page (download/export, local dev, the
* sandbox's own `npm run preview`) is not framed by any preview, so no token
* can ever arrive: the hook reports `not_embedded` without probing. Any framed
* page probes, even when the parent origin cannot be resolved (empty referrer,
* no `ancestorOrigins`): the token comes through the preview proxy, and the
* bridge event is only the faster signal.
*/
function useRefetchWhenConnectorReady(waiting, refetch) {
	const refetchRef = (0, import_react.useRef)(refetch);
	const [timedOut, setTimedOut] = (0, import_react.useState)(false);
	const [notEmbedded, setNotEmbedded] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		refetchRef.current = refetch;
	}, [refetch]);
	(0, import_react.useEffect)(() => {
		if (!waiting) return;
		if (!isFramed()) {
			setNotEmbedded(true);
			return () => setNotEmbedded(false);
		}
		let cancelled = false;
		let refetching = false;
		let attempt = 0;
		let timer;
		const startedAt = Date.now();
		const runRefetch = async () => {
			if (refetching) return;
			refetching = true;
			try {
				await refetchRef.current();
			} catch {} finally {
				refetching = false;
			}
		};
		const schedule = () => {
			timer = setTimeout(probe, readinessProbeDelayMs(attempt));
			attempt += 1;
		};
		const probe = async () => {
			if (cancelled || readinessProbeExhausted(startedAt, Date.now())) return;
			const ready = await isConnectorReady();
			if (cancelled) return;
			if (ready) await runRefetch();
			if (!cancelled) schedule();
		};
		const onTokenReady = () => {
			runRefetch();
		};
		const deadline = setTimeout(() => {
			if (!cancelled) setTimedOut(true);
		}, READINESS_PROBE_MAX_TOTAL_MS);
		window.addEventListener(CONNECTOR_TOKEN_READY_EVENT, onTokenReady);
		schedule();
		return () => {
			cancelled = true;
			clearTimeout(deadline);
			if (timer !== void 0) clearTimeout(timer);
			window.removeEventListener(CONNECTOR_TOKEN_READY_EVENT, onTokenReady);
			setTimedOut(false);
		};
	}, [waiting]);
	if (!waiting) return "idle";
	if (notEmbedded) return "not_embedded";
	return timedOut ? "timed_out" : "waiting";
}
function Desk() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [calendar, setCalendar] = (0, import_react.useState)(null);
	const [drive, setDrive] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const load = (0, import_react.useCallback)(async () => {
		setBusy(true);
		try {
			const result = await fetchDesk({ data: { driveQuery: query } });
			setCalendar(result.calendar);
			setDrive(result.drive);
		} catch {
			const fail = {
				ok: false,
				message: "এখন লোড হয়নি। Grok থেকে খুললে ক্যালেন্ডার ও ড্রাইভ আসে।",
				loginRequired: false,
				pending: false,
				rows: []
			};
			setCalendar(fail);
			setDrive(fail);
		} finally {
			setBusy(false);
		}
	}, [query]);
	useRefetchWhenConnectorReady(Boolean(calendar?.pending || drive?.pending), () => {
		load();
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
			kicker: "ডেস্ক",
			title: "আপনার ক্যালেন্ডার ও ড্রাইভ।",
			lede: "Gmail আর Notion এই ঘরে জোড়া নেই — যে টুল খোলা আছে সেগুলো ক্যালেন্ডার ও ড্রাইভ। Grok-এ অ্যাকাউন্ট জুড়লে খবর আসে।"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex flex-wrap gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: `${control} max-w-xs`,
				placeholder: "ড্রাইভে খুঁজুন",
				value: query,
				onChange: (e) => setQuery(e.target.value)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				type: "button",
				onClick: () => void load(),
				disabled: busy,
				children: busy ? "আসছে…" : "আনুন"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pane, {
				title: "সামনের সাত দিন",
				block: calendar
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pane, {
				title: "ড্রাইভ",
				block: drive
			})]
		})
	] });
}
function Pane({ title, block }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-md border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl",
				children: title
			}),
			!block ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: "এখনো আনা হয়নি।"
			}) : null,
			block && !block.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: block.message
			}) : null,
			block?.loginRequired ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-3 min-h-11 text-primary",
				onClick: () => redirectToLoginIfRequired({
					ok: false,
					data: null,
					loginRequired: true,
					loginUrl: block.loginUrl
				}),
				children: "Grok দিয়ে চালিয়ে যান"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-2",
				children: block?.rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "border-b border-line py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: row.title }), row.meta ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: row.meta
					}) : null]
				}, `${row.title}-${row.meta}`))
			}),
			block?.ok && block.rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: "কিছু পাওয়া যায়নি।"
			}) : null
		]
	});
}
//#endregion
export { Desk as component };
