//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-56SxYfxW.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/board",
			"/day",
			"/desk",
			"/login",
			"/make",
			"/me",
			"/money",
			"/share",
			"/sites",
			"/work",
			"/s/$code",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-CMJ3Zf9-.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/preload-helper-CuP9zDxQ.js",
			"/assets/link-CjZ2n7Rf.js",
			"/assets/jsx-runtime-BtH0gOTJ.js",
			"/assets/gates-BhKBWSQs.js",
			"/assets/use-current-user-DQB55Vmc.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CMJ3Zf9-.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-pneua3IV.js"]
	},
	"/board": {
		filePath: "/workspace/src/routes/board.tsx",
		children: void 0,
		preloads: ["/assets/board-DdazwO42.js", "/assets/ui-B4-RBZHx.js"]
	},
	"/day": {
		filePath: "/workspace/src/routes/day.tsx",
		children: void 0,
		preloads: [
			"/assets/day-FmQhAe0m.js",
			"/assets/ui-B4-RBZHx.js",
			"/assets/content-C4o95DBJ.js",
			"/assets/use-items-DCll2nl3.js"
		]
	},
	"/desk": {
		filePath: "/workspace/src/routes/desk.tsx",
		children: void 0,
		preloads: ["/assets/desk-DYNkOHSv.js", "/assets/ui-B4-RBZHx.js"]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-Djy4krC_.js"]
	},
	"/make": {
		filePath: "/workspace/src/routes/make.tsx",
		children: void 0,
		preloads: [
			"/assets/make-TiX5NtUa.js",
			"/assets/ui-B4-RBZHx.js",
			"/assets/content-C4o95DBJ.js",
			"/assets/use-items-DCll2nl3.js"
		]
	},
	"/me": {
		filePath: "/workspace/src/routes/me.tsx",
		children: void 0,
		preloads: ["/assets/me-B2x2rWUB.js", "/assets/ui-B4-RBZHx.js"]
	},
	"/money": {
		filePath: "/workspace/src/routes/money.tsx",
		children: void 0,
		preloads: [
			"/assets/money-CHpo1Ph2.js",
			"/assets/ui-B4-RBZHx.js",
			"/assets/content-C4o95DBJ.js",
			"/assets/use-items-DCll2nl3.js"
		]
	},
	"/share": {
		filePath: "/workspace/src/routes/share.tsx",
		children: void 0,
		preloads: ["/assets/share-CgzItdLQ.js", "/assets/ui-B4-RBZHx.js"]
	},
	"/sites": {
		filePath: "/workspace/src/routes/sites.tsx",
		children: void 0,
		preloads: [
			"/assets/sites-D44CeTuw.js",
			"/assets/ui-B4-RBZHx.js",
			"/assets/content-C4o95DBJ.js",
			"/assets/use-items-DCll2nl3.js"
		]
	},
	"/work": {
		filePath: "/workspace/src/routes/work.tsx",
		children: void 0,
		preloads: [
			"/assets/work-PfpnfJn2.js",
			"/assets/ui-B4-RBZHx.js",
			"/assets/use-items-DCll2nl3.js"
		]
	},
	"/s/$code": {
		filePath: "/workspace/src/routes/s.$code.tsx",
		children: void 0,
		preloads: ["/assets/s._code-Gq9EDqKS.js", "/assets/ui-B4-RBZHx.js"]
	}
} });
//#endregion
export { tsrStartManifest };
